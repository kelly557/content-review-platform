--
-- PostgreSQL database dump
--

\restrict pGc6ecvJTYiVVp16desd2Hc3Z7HedmPvii9KBikzedw9CEgSCfj7agrv0tEYK5H

-- Dumped from database version 17.9 (Homebrew)
-- Dumped by pg_dump version 17.9 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.workflow_nodes DROP CONSTRAINT IF EXISTS workflow_nodes_instance_id_fkey;
ALTER TABLE IF EXISTS ONLY public.workflow_instances DROP CONSTRAINT IF EXISTS workflow_instances_template_id_fkey;
ALTER TABLE IF EXISTS ONLY public.workflow_instances DROP CONSTRAINT IF EXISTS workflow_instances_material_version_id_fkey;
ALTER TABLE IF EXISTS ONLY public.workflow_instances DROP CONSTRAINT IF EXISTS workflow_instances_material_id_fkey;
ALTER TABLE IF EXISTS ONLY public.triggers DROP CONSTRAINT IF EXISTS triggers_strategy_id_fkey;
ALTER TABLE IF EXISTS ONLY public.triggers DROP CONSTRAINT IF EXISTS triggers_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.trigger_runs DROP CONSTRAINT IF EXISTS trigger_runs_trigger_id_fkey;
ALTER TABLE IF EXISTS ONLY public.strategy_points_v2 DROP CONSTRAINT IF EXISTS strategy_points_v2_rule_set_id_fkey;
ALTER TABLE IF EXISTS ONLY public.strategy_points_v2 DROP CONSTRAINT IF EXISTS strategy_points_v2_point_id_fkey;
ALTER TABLE IF EXISTS ONLY public.strategy_points_v2 DROP CONSTRAINT IF EXISTS strategy_points_v2_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.strategy_points DROP CONSTRAINT IF EXISTS strategy_points_strategy_id_fkey;
ALTER TABLE IF EXISTS ONLY public.strategy_points DROP CONSTRAINT IF EXISTS strategy_points_point_id_fkey;
ALTER TABLE IF EXISTS ONLY public.strategy_points DROP CONSTRAINT IF EXISTS strategy_points_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.strategy_items DROP CONSTRAINT IF EXISTS strategy_items_strategy_id_fkey;
ALTER TABLE IF EXISTS ONLY public.strategy_items DROP CONSTRAINT IF EXISTS strategy_items_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.strategies DROP CONSTRAINT IF EXISTS strategies_created_by_id_fkey;
ALTER TABLE IF EXISTS ONLY public.services DROP CONSTRAINT IF EXISTS services_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rule_sets DROP CONSTRAINT IF EXISTS rule_sets_locked_by_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rule_sets DROP CONSTRAINT IF EXISTS rule_sets_created_by_id_fkey;
ALTER TABLE IF EXISTS ONLY public.review_tasks DROP CONSTRAINT IF EXISTS review_tasks_workflow_instance_id_fkey;
ALTER TABLE IF EXISTS ONLY public.review_tasks DROP CONSTRAINT IF EXISTS review_tasks_material_version_id_fkey;
ALTER TABLE IF EXISTS ONLY public.review_tasks DROP CONSTRAINT IF EXISTS review_tasks_material_id_fkey;
ALTER TABLE IF EXISTS ONLY public.review_tasks DROP CONSTRAINT IF EXISTS review_tasks_canceled_by_fkey;
ALTER TABLE IF EXISTS ONLY public.review_assignments DROP CONSTRAINT IF EXISTS review_assignments_task_id_fkey;
ALTER TABLE IF EXISTS ONLY public.review_assignments DROP CONSTRAINT IF EXISTS review_assignments_assignee_id_fkey;
ALTER TABLE IF EXISTS ONLY public.review_assignment_tags DROP CONSTRAINT IF EXISTS review_assignment_tags_assignment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.materials DROP CONSTRAINT IF EXISTS materials_submitter_id_fkey;
ALTER TABLE IF EXISTS ONLY public.materials DROP CONSTRAINT IF EXISTS materials_current_version_id_fkey;
ALTER TABLE IF EXISTS ONLY public.material_versions DROP CONSTRAINT IF EXISTS material_versions_material_id_fkey;
ALTER TABLE IF EXISTS ONLY public.material_versions DROP CONSTRAINT IF EXISTS material_versions_created_by_id_fkey;
ALTER TABLE IF EXISTS ONLY public.material_packages DROP CONSTRAINT IF EXISTS material_packages_creator_id_fkey;
ALTER TABLE IF EXISTS ONLY public.material_package_items DROP CONSTRAINT IF EXISTS material_package_items_review_task_id_fkey;
ALTER TABLE IF EXISTS ONLY public.material_package_items DROP CONSTRAINT IF EXISTS material_package_items_package_id_fkey;
ALTER TABLE IF EXISTS ONLY public.material_package_items DROP CONSTRAINT IF EXISTS material_package_items_material_id_fkey;
ALTER TABLE IF EXISTS ONLY public.llm_calls DROP CONSTRAINT IF EXISTS llm_calls_version_id_fkey;
ALTER TABLE IF EXISTS ONLY public.llm_calls DROP CONSTRAINT IF EXISTS llm_calls_task_id_fkey;
ALTER TABLE IF EXISTS ONLY public.library_items DROP CONSTRAINT IF EXISTS library_items_library_id_fkey;
ALTER TABLE IF EXISTS ONLY public.library_item_references DROP CONSTRAINT IF EXISTS library_item_references_library_id_fkey;
ALTER TABLE IF EXISTS ONLY public.library_item_references DROP CONSTRAINT IF EXISTS library_item_references_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.image_set_items DROP CONSTRAINT IF EXISTS image_set_items_set_id_fkey;
ALTER TABLE IF EXISTS ONLY public.human_review_configs DROP CONSTRAINT IF EXISTS human_review_configs_service_code_fkey;
ALTER TABLE IF EXISTS ONLY public.human_review_configs DROP CONSTRAINT IF EXISTS human_review_configs_review_rule_id_fkey;
ALTER TABLE IF EXISTS ONLY public.strategies DROP CONSTRAINT IF EXISTS fk_strategies_rule_set;
ALTER TABLE IF EXISTS ONLY public.strategies DROP CONSTRAINT IF EXISTS fk_strategies_disposition_rule;
ALTER TABLE IF EXISTS ONLY public.review_assignment_audit_items DROP CONSTRAINT IF EXISTS fk_raai_audit_item;
ALTER TABLE IF EXISTS ONLY public.review_assignment_audit_items DROP CONSTRAINT IF EXISTS fk_raai_assignment;
ALTER TABLE IF EXISTS ONLY public.disposition_rules DROP CONSTRAINT IF EXISTS disposition_rules_review_rule_id_fkey;
ALTER TABLE IF EXISTS ONLY public.disposition_rules DROP CONSTRAINT IF EXISTS disposition_rules_locked_by_id_fkey;
ALTER TABLE IF EXISTS ONLY public.disposition_rules DROP CONSTRAINT IF EXISTS disposition_rules_created_by_id_fkey;
ALTER TABLE IF EXISTS ONLY public.detection_rules DROP CONSTRAINT IF EXISTS detection_rules_service_code_fkey;
ALTER TABLE IF EXISTS ONLY public.detection_rules DROP CONSTRAINT IF EXISTS detection_rules_custom_wordset_id_fkey;
ALTER TABLE IF EXISTS ONLY public.detection_rules DROP CONSTRAINT IF EXISTS detection_rules_audit_point_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_points DROP CONSTRAINT IF EXISTS audit_points_package_code_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_points DROP CONSTRAINT IF EXISTS audit_points_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_points DROP CONSTRAINT IF EXISTS audit_points_custom_wordset_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_points DROP CONSTRAINT IF EXISTS audit_points_custom_reply_library_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_points DROP CONSTRAINT IF EXISTS audit_points_custom_library_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_point_libraries DROP CONSTRAINT IF EXISTS audit_point_libraries_library_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_point_libraries DROP CONSTRAINT IF EXISTS audit_point_libraries_audit_point_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_items DROP CONSTRAINT IF EXISTS audit_items_package_code_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_events DROP CONSTRAINT IF EXISTS audit_events_actor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.annotations DROP CONSTRAINT IF EXISTS annotations_parent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.annotations DROP CONSTRAINT IF EXISTS annotations_material_version_id_fkey;
ALTER TABLE IF EXISTS ONLY public.annotations DROP CONSTRAINT IF EXISTS annotations_author_id_fkey;
ALTER TABLE IF EXISTS ONLY public.alert_events DROP CONSTRAINT IF EXISTS alert_events_ack_by_fkey;
DROP INDEX IF EXISTS public.ix_workflow_templates_public_id;
DROP INDEX IF EXISTS public.ix_workflow_nodes_status;
DROP INDEX IF EXISTS public.ix_workflow_nodes_public_id;
DROP INDEX IF EXISTS public.ix_workflow_nodes_instance_id;
DROP INDEX IF EXISTS public.ix_workflow_instances_state;
DROP INDEX IF EXISTS public.ix_workflow_instances_public_id;
DROP INDEX IF EXISTS public.ix_workflow_instances_material_version_id;
DROP INDEX IF EXISTS public.ix_workflow_instances_material_id;
DROP INDEX IF EXISTS public.ix_word_sets_public_id;
DROP INDEX IF EXISTS public.ix_word_sets_kind;
DROP INDEX IF EXISTS public.ix_word_sets_group_action;
DROP INDEX IF EXISTS public.ix_word_sets_group;
DROP INDEX IF EXISTS public.ix_word_sets_code;
DROP INDEX IF EXISTS public.ix_word_sets_action_active;
DROP INDEX IF EXISTS public.ix_word_sets_action;
DROP INDEX IF EXISTS public.ix_users_public_id;
DROP INDEX IF EXISTS public.ix_users_email;
DROP INDEX IF EXISTS public.ix_triggers_public_id;
DROP INDEX IF EXISTS public.ix_triggers_enabled_type;
DROP INDEX IF EXISTS public.ix_triggers_code;
DROP INDEX IF EXISTS public.ix_trigger_runs_trigger;
DROP INDEX IF EXISTS public.ix_trigger_runs_started;
DROP INDEX IF EXISTS public.ix_trigger_runs_public_id;
DROP INDEX IF EXISTS public.ix_tags_status;
DROP INDEX IF EXISTS public.ix_tags_domain;
DROP INDEX IF EXISTS public.ix_tags_deleted_at;
DROP INDEX IF EXISTS public.ix_tags_code;
DROP INDEX IF EXISTS public.ix_tags_category;
DROP INDEX IF EXISTS public.ix_tag_domain_category;
DROP INDEX IF EXISTS public.ix_strategy_points_v2_public_id;
DROP INDEX IF EXISTS public.ix_strategy_points_strategy_id;
DROP INDEX IF EXISTS public.ix_strategy_points_strategy;
DROP INDEX IF EXISTS public.ix_strategy_points_public_id;
DROP INDEX IF EXISTS public.ix_strategy_items_strategy_id;
DROP INDEX IF EXISTS public.ix_strategy_items_strategy;
DROP INDEX IF EXISTS public.ix_strategy_items_public_id;
DROP INDEX IF EXISTS public.ix_strategies_scope;
DROP INDEX IF EXISTS public.ix_strategies_rule_set_id;
DROP INDEX IF EXISTS public.ix_strategies_public_id;
DROP INDEX IF EXISTS public.ix_strategies_disposition_rule_id;
DROP INDEX IF EXISTS public.ix_strategies_code;
DROP INDEX IF EXISTS public.ix_sp_v2_rs;
DROP INDEX IF EXISTS public.ix_services_scope;
DROP INDEX IF EXISTS public.ix_services_public_id;
DROP INDEX IF EXISTS public.ix_services_code;
DROP INDEX IF EXISTS public.ix_services_category_id;
DROP INDEX IF EXISTS public.ix_service_scope_active;
DROP INDEX IF EXISTS public.ix_service_categories_public_id;
DROP INDEX IF EXISTS public.ix_service_categories_code;
DROP INDEX IF EXISTS public.ix_rule_sets_public_id;
DROP INDEX IF EXISTS public.ix_review_tasks_workflow_instance_id;
DROP INDEX IF EXISTS public.ix_review_tasks_review_type;
DROP INDEX IF EXISTS public.ix_review_tasks_public_id;
DROP INDEX IF EXISTS public.ix_review_tasks_material_id;
DROP INDEX IF EXISTS public.ix_review_tasks_machine_status;
DROP INDEX IF EXISTS public.ix_review_tasks_final_decision;
DROP INDEX IF EXISTS public.ix_review_tasks_canceled_at;
DROP INDEX IF EXISTS public.ix_review_task_stage;
DROP INDEX IF EXISTS public.ix_review_assignments_task_id;
DROP INDEX IF EXISTS public.ix_review_assignments_public_id;
DROP INDEX IF EXISTS public.ix_review_assignments_assignee_id;
DROP INDEX IF EXISTS public.ix_review_assignment_tags_tag_id;
DROP INDEX IF EXISTS public.ix_review_assignment_tags_public_id;
DROP INDEX IF EXISTS public.ix_review_assignment_tags_assignment_id;
DROP INDEX IF EXISTS public.ix_rat_assignment_tag;
DROP INDEX IF EXISTS public.ix_raai_public_id;
DROP INDEX IF EXISTS public.ix_raai_audit_item_id;
DROP INDEX IF EXISTS public.ix_raai_assignment_item;
DROP INDEX IF EXISTS public.ix_raai_assignment_id;
DROP INDEX IF EXISTS public.ix_ops_log_status;
DROP INDEX IF EXISTS public.ix_ops_log_public_id;
DROP INDEX IF EXISTS public.ix_ops_log_created_at;
DROP INDEX IF EXISTS public.ix_ops_log_action_created_at;
DROP INDEX IF EXISTS public.ix_ops_log_action;
DROP INDEX IF EXISTS public.ix_materials_submitter_id;
DROP INDEX IF EXISTS public.ix_materials_status_type;
DROP INDEX IF EXISTS public.ix_materials_status;
DROP INDEX IF EXISTS public.ix_materials_public_id;
DROP INDEX IF EXISTS public.ix_material_versions_public_id;
DROP INDEX IF EXISTS public.ix_material_versions_material_id;
DROP INDEX IF EXISTS public.ix_material_version_unique;
DROP INDEX IF EXISTS public.ix_material_packages_status;
DROP INDEX IF EXISTS public.ix_material_packages_public_id;
DROP INDEX IF EXISTS public.ix_material_packages_creator_id;
DROP INDEX IF EXISTS public.ix_material_package_items_public_id;
DROP INDEX IF EXISTS public.ix_material_package_items_package_id;
DROP INDEX IF EXISTS public.ix_material_package_items_material_id;
DROP INDEX IF EXISTS public.ix_llm_calls_task_id;
DROP INDEX IF EXISTS public.ix_llm_calls_public_id;
DROP INDEX IF EXISTS public.ix_llm_calls_ok;
DROP INDEX IF EXISTS public.ix_llm_calls_created_at;
DROP INDEX IF EXISTS public.ix_llm_calls_correlation_id;
DROP INDEX IF EXISTS public.ix_library_items_word;
DROP INDEX IF EXISTS public.ix_library_items_sha;
DROP INDEX IF EXISTS public.ix_library_items_public_id;
DROP INDEX IF EXISTS public.ix_library_items_library_active;
DROP INDEX IF EXISTS public.ix_library_item_references_library;
DROP INDEX IF EXISTS public.ix_libraries_type_kind_active;
DROP INDEX IF EXISTS public.ix_libraries_public_id;
DROP INDEX IF EXISTS public.ix_libraries_effective_range;
DROP INDEX IF EXISTS public.ix_image_sets_public_id;
DROP INDEX IF EXISTS public.ix_image_sets_kind;
DROP INDEX IF EXISTS public.ix_image_sets_group_action;
DROP INDEX IF EXISTS public.ix_image_sets_group;
DROP INDEX IF EXISTS public.ix_image_sets_code;
DROP INDEX IF EXISTS public.ix_image_sets_action_active;
DROP INDEX IF EXISTS public.ix_image_sets_action;
DROP INDEX IF EXISTS public.ix_image_set_items_set_id;
DROP INDEX IF EXISTS public.ix_image_set_items_public_id;
DROP INDEX IF EXISTS public.ix_human_review_configs_service_code;
DROP INDEX IF EXISTS public.ix_human_review_configs_public_id;
DROP INDEX IF EXISTS public.ix_disposition_rules_public_id;
DROP INDEX IF EXISTS public.ix_detection_rules_service_label;
DROP INDEX IF EXISTS public.ix_detection_rules_service_code;
DROP INDEX IF EXISTS public.ix_detection_rules_public_id;
DROP INDEX IF EXISTS public.ix_detection_rules_audit_point_id;
DROP INDEX IF EXISTS public.ix_audit_points_public_id;
DROP INDEX IF EXISTS public.ix_audit_points_package_code;
DROP INDEX IF EXISTS public.ix_audit_points_item_id;
DROP INDEX IF EXISTS public.ix_audit_point_libraries_lib;
DROP INDEX IF EXISTS public.ix_audit_point_item;
DROP INDEX IF EXISTS public.ix_audit_items_public_id;
DROP INDEX IF EXISTS public.ix_audit_items_package_code;
DROP INDEX IF EXISTS public.ix_audit_events_public_id;
DROP INDEX IF EXISTS public.ix_audit_events_entity_type;
DROP INDEX IF EXISTS public.ix_audit_events_entity_id;
DROP INDEX IF EXISTS public.ix_audit_events_created_at;
DROP INDEX IF EXISTS public.ix_audit_events_action;
DROP INDEX IF EXISTS public.ix_audit_entity;
DROP INDEX IF EXISTS public.ix_annotations_public_id;
DROP INDEX IF EXISTS public.ix_annotations_material_version_id;
DROP INDEX IF EXISTS public.ix_alert_status_created;
DROP INDEX IF EXISTS public.ix_alert_rule_window;
DROP INDEX IF EXISTS public.ix_alert_events_status;
DROP INDEX IF EXISTS public.ix_alert_events_rule_code;
DROP INDEX IF EXISTS public.ix_alert_events_public_id;
DROP INDEX IF EXISTS public.ix_alert_events_metric;
DROP INDEX IF EXISTS public.ix_alert_events_created_at;
ALTER TABLE IF EXISTS ONLY public.workflow_templates DROP CONSTRAINT IF EXISTS workflow_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.workflow_templates DROP CONSTRAINT IF EXISTS workflow_templates_code_key;
ALTER TABLE IF EXISTS ONLY public.workflow_nodes DROP CONSTRAINT IF EXISTS workflow_nodes_pkey;
ALTER TABLE IF EXISTS ONLY public.workflow_instances DROP CONSTRAINT IF EXISTS workflow_instances_pkey;
ALTER TABLE IF EXISTS ONLY public.word_sets DROP CONSTRAINT IF EXISTS word_sets_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.strategy_points DROP CONSTRAINT IF EXISTS uq_strategy_point;
ALTER TABLE IF EXISTS ONLY public.strategy_items DROP CONSTRAINT IF EXISTS uq_strategy_item;
ALTER TABLE IF EXISTS ONLY public.rule_sets DROP CONSTRAINT IF EXISTS uq_rule_sets_code;
ALTER TABLE IF EXISTS ONLY public.strategy_points_v2 DROP CONSTRAINT IF EXISTS uq_rs_point_v2;
ALTER TABLE IF EXISTS ONLY public.review_assignment_audit_items DROP CONSTRAINT IF EXISTS uq_raai_public_id;
ALTER TABLE IF EXISTS ONLY public.material_package_items DROP CONSTRAINT IF EXISTS uq_package_item;
ALTER TABLE IF EXISTS ONLY public.llm_calls DROP CONSTRAINT IF EXISTS uq_llm_calls_public_id;
ALTER TABLE IF EXISTS ONLY public.disposition_rules DROP CONSTRAINT IF EXISTS uq_disposition_rules_code;
ALTER TABLE IF EXISTS ONLY public.audit_points DROP CONSTRAINT IF EXISTS uq_audit_point_pkg_code;
ALTER TABLE IF EXISTS ONLY public.audit_items DROP CONSTRAINT IF EXISTS uq_audit_item_pkg_code;
ALTER TABLE IF EXISTS ONLY public.triggers DROP CONSTRAINT IF EXISTS triggers_pkey;
ALTER TABLE IF EXISTS ONLY public.trigger_runs DROP CONSTRAINT IF EXISTS trigger_runs_pkey;
ALTER TABLE IF EXISTS ONLY public.tags DROP CONSTRAINT IF EXISTS tags_pkey;
ALTER TABLE IF EXISTS ONLY public.strategy_points_v2 DROP CONSTRAINT IF EXISTS strategy_points_v2_public_id_key;
ALTER TABLE IF EXISTS ONLY public.strategy_points_v2 DROP CONSTRAINT IF EXISTS strategy_points_v2_pkey;
ALTER TABLE IF EXISTS ONLY public.strategy_points DROP CONSTRAINT IF EXISTS strategy_points_pkey;
ALTER TABLE IF EXISTS ONLY public.strategy_items DROP CONSTRAINT IF EXISTS strategy_items_pkey;
ALTER TABLE IF EXISTS ONLY public.strategies DROP CONSTRAINT IF EXISTS strategies_pkey;
ALTER TABLE IF EXISTS ONLY public.services DROP CONSTRAINT IF EXISTS services_pkey;
ALTER TABLE IF EXISTS ONLY public.service_categories DROP CONSTRAINT IF EXISTS service_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.rule_sets DROP CONSTRAINT IF EXISTS rule_sets_public_id_key;
ALTER TABLE IF EXISTS ONLY public.rule_sets DROP CONSTRAINT IF EXISTS rule_sets_pkey;
ALTER TABLE IF EXISTS ONLY public.review_tasks DROP CONSTRAINT IF EXISTS review_tasks_pkey;
ALTER TABLE IF EXISTS ONLY public.review_assignments DROP CONSTRAINT IF EXISTS review_assignments_pkey;
ALTER TABLE IF EXISTS ONLY public.review_assignment_tags DROP CONSTRAINT IF EXISTS review_assignment_tags_pkey;
ALTER TABLE IF EXISTS ONLY public.review_assignment_audit_items DROP CONSTRAINT IF EXISTS review_assignment_audit_items_pkey;
ALTER TABLE IF EXISTS ONLY public.ops_log DROP CONSTRAINT IF EXISTS ops_log_pkey;
ALTER TABLE IF EXISTS ONLY public.materials DROP CONSTRAINT IF EXISTS materials_pkey;
ALTER TABLE IF EXISTS ONLY public.material_versions DROP CONSTRAINT IF EXISTS material_versions_pkey;
ALTER TABLE IF EXISTS ONLY public.material_packages DROP CONSTRAINT IF EXISTS material_packages_pkey;
ALTER TABLE IF EXISTS ONLY public.material_package_items DROP CONSTRAINT IF EXISTS material_package_items_pkey;
ALTER TABLE IF EXISTS ONLY public.llm_calls DROP CONSTRAINT IF EXISTS llm_calls_pkey;
ALTER TABLE IF EXISTS ONLY public.library_items DROP CONSTRAINT IF EXISTS library_items_pkey;
ALTER TABLE IF EXISTS ONLY public.library_item_references DROP CONSTRAINT IF EXISTS library_item_references_pkey;
ALTER TABLE IF EXISTS ONLY public.libraries DROP CONSTRAINT IF EXISTS libraries_pkey;
ALTER TABLE IF EXISTS ONLY public.libraries DROP CONSTRAINT IF EXISTS libraries_code_key;
ALTER TABLE IF EXISTS ONLY public.image_sets DROP CONSTRAINT IF EXISTS image_sets_pkey;
ALTER TABLE IF EXISTS ONLY public.image_set_items DROP CONSTRAINT IF EXISTS image_set_items_pkey;
ALTER TABLE IF EXISTS ONLY public.human_review_configs DROP CONSTRAINT IF EXISTS human_review_configs_pkey;
ALTER TABLE IF EXISTS ONLY public.disposition_rules DROP CONSTRAINT IF EXISTS disposition_rules_public_id_key;
ALTER TABLE IF EXISTS ONLY public.disposition_rules DROP CONSTRAINT IF EXISTS disposition_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.detection_rules DROP CONSTRAINT IF EXISTS detection_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_points DROP CONSTRAINT IF EXISTS audit_points_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_point_libraries DROP CONSTRAINT IF EXISTS audit_point_libraries_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_items DROP CONSTRAINT IF EXISTS audit_items_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_events DROP CONSTRAINT IF EXISTS audit_events_pkey;
ALTER TABLE IF EXISTS ONLY public.annotations DROP CONSTRAINT IF EXISTS annotations_pkey;
ALTER TABLE IF EXISTS ONLY public.alert_events DROP CONSTRAINT IF EXISTS alert_events_pkey;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS public.workflow_templates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.workflow_nodes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.workflow_instances ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.word_sets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.triggers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.trigger_runs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.strategy_points_v2 ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.strategy_points ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.strategy_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.strategies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.services ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.service_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rule_sets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.review_tasks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.review_assignments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.review_assignment_tags ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.review_assignment_audit_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ops_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.materials ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.material_versions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.material_packages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.material_package_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.llm_calls ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.library_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.libraries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.image_sets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.image_set_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.human_review_configs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.disposition_rules ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.detection_rules ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.audit_points ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.audit_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.audit_events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.annotations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.alert_events ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.workflow_templates_id_seq;
DROP TABLE IF EXISTS public.workflow_templates;
DROP SEQUENCE IF EXISTS public.workflow_nodes_id_seq;
DROP TABLE IF EXISTS public.workflow_nodes;
DROP SEQUENCE IF EXISTS public.workflow_instances_id_seq;
DROP TABLE IF EXISTS public.workflow_instances;
DROP SEQUENCE IF EXISTS public.word_sets_id_seq;
DROP TABLE IF EXISTS public.word_sets;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.triggers_id_seq;
DROP TABLE IF EXISTS public.triggers;
DROP SEQUENCE IF EXISTS public.trigger_runs_id_seq;
DROP TABLE IF EXISTS public.trigger_runs;
DROP TABLE IF EXISTS public.tags;
DROP SEQUENCE IF EXISTS public.strategy_points_v2_id_seq;
DROP TABLE IF EXISTS public.strategy_points_v2;
DROP SEQUENCE IF EXISTS public.strategy_points_id_seq;
DROP TABLE IF EXISTS public.strategy_points;
DROP SEQUENCE IF EXISTS public.strategy_items_id_seq;
DROP TABLE IF EXISTS public.strategy_items;
DROP SEQUENCE IF EXISTS public.strategies_id_seq;
DROP TABLE IF EXISTS public.strategies;
DROP SEQUENCE IF EXISTS public.services_id_seq;
DROP TABLE IF EXISTS public.services;
DROP SEQUENCE IF EXISTS public.service_categories_id_seq;
DROP TABLE IF EXISTS public.service_categories;
DROP SEQUENCE IF EXISTS public.rule_sets_id_seq;
DROP TABLE IF EXISTS public.rule_sets;
DROP SEQUENCE IF EXISTS public.review_tasks_id_seq;
DROP TABLE IF EXISTS public.review_tasks;
DROP SEQUENCE IF EXISTS public.review_assignments_id_seq;
DROP TABLE IF EXISTS public.review_assignments;
DROP SEQUENCE IF EXISTS public.review_assignment_tags_id_seq;
DROP TABLE IF EXISTS public.review_assignment_tags;
DROP SEQUENCE IF EXISTS public.review_assignment_audit_items_id_seq;
DROP TABLE IF EXISTS public.review_assignment_audit_items;
DROP SEQUENCE IF EXISTS public.ops_log_id_seq;
DROP TABLE IF EXISTS public.ops_log;
DROP SEQUENCE IF EXISTS public.materials_id_seq;
DROP TABLE IF EXISTS public.materials;
DROP SEQUENCE IF EXISTS public.material_versions_id_seq;
DROP TABLE IF EXISTS public.material_versions;
DROP SEQUENCE IF EXISTS public.material_packages_id_seq;
DROP TABLE IF EXISTS public.material_packages;
DROP SEQUENCE IF EXISTS public.material_package_items_id_seq;
DROP TABLE IF EXISTS public.material_package_items;
DROP SEQUENCE IF EXISTS public.llm_calls_id_seq;
DROP TABLE IF EXISTS public.llm_calls;
DROP SEQUENCE IF EXISTS public.library_items_id_seq;
DROP TABLE IF EXISTS public.library_items;
DROP TABLE IF EXISTS public.library_item_references;
DROP SEQUENCE IF EXISTS public.libraries_id_seq;
DROP TABLE IF EXISTS public.libraries;
DROP SEQUENCE IF EXISTS public.image_sets_id_seq;
DROP TABLE IF EXISTS public.image_sets;
DROP SEQUENCE IF EXISTS public.image_set_items_id_seq;
DROP TABLE IF EXISTS public.image_set_items;
DROP SEQUENCE IF EXISTS public.human_review_configs_id_seq;
DROP TABLE IF EXISTS public.human_review_configs;
DROP SEQUENCE IF EXISTS public.disposition_rules_id_seq;
DROP TABLE IF EXISTS public.disposition_rules;
DROP SEQUENCE IF EXISTS public.detection_rules_id_seq;
DROP TABLE IF EXISTS public.detection_rules;
DROP SEQUENCE IF EXISTS public.audit_points_id_seq;
DROP TABLE IF EXISTS public.audit_points;
DROP TABLE IF EXISTS public.audit_point_libraries;
DROP SEQUENCE IF EXISTS public.audit_items_id_seq;
DROP TABLE IF EXISTS public.audit_items;
DROP SEQUENCE IF EXISTS public.audit_events_id_seq;
DROP TABLE IF EXISTS public.audit_events;
DROP SEQUENCE IF EXISTS public.annotations_id_seq;
DROP TABLE IF EXISTS public.annotations;
DROP SEQUENCE IF EXISTS public.alert_events_id_seq;
DROP TABLE IF EXISTS public.alert_events;
DROP TABLE IF EXISTS public.alembic_version;
DROP TYPE IF EXISTS public.wordsetkind;
DROP TYPE IF EXISTS public.wordsetgroup;
DROP TYPE IF EXISTS public.wordsetaction;
DROP TYPE IF EXISTS public.userrole;
DROP TYPE IF EXISTS public.tagstatus;
DROP TYPE IF EXISTS public.tagdomain;
DROP TYPE IF EXISTS public.tagcategory;
DROP TYPE IF EXISTS public.strategyscope;
DROP TYPE IF EXISTS public.servicescope;
DROP TYPE IF EXISTS public.reviewtype;
DROP TYPE IF EXISTS public.reviewdecision;
DROP TYPE IF EXISTS public.packagestatus;
DROP TYPE IF EXISTS public.materialtype;
DROP TYPE IF EXISTS public.materialstatus;
DROP TYPE IF EXISTS public.machinestatus;
DROP TYPE IF EXISTS public.librarytype;
DROP TYPE IF EXISTS public.librarykind;
DROP TYPE IF EXISTS public.imagesetkind;
DROP TYPE IF EXISTS public.imagesetgroup;
DROP TYPE IF EXISTS public.imagesetaction;
DROP TYPE IF EXISTS public.auditpointrisk;
DROP SCHEMA IF EXISTS test_ffb9edcd4eef;
DROP SCHEMA IF EXISTS test_f393c25cbbe3;
DROP SCHEMA IF EXISTS test_ed1fb678ad44;
DROP SCHEMA IF EXISTS test_eaf60fd28fc7;
DROP SCHEMA IF EXISTS test_e711a0eb0b15;
DROP SCHEMA IF EXISTS test_e4af720996a9;
DROP SCHEMA IF EXISTS test_e25f2b3f22e0;
DROP SCHEMA IF EXISTS test_e15ee6a5935a;
DROP SCHEMA IF EXISTS test_d2437f804d5d;
DROP SCHEMA IF EXISTS test_cf9ccd7e5c54;
DROP SCHEMA IF EXISTS test_ca17f2fa2e6a;
DROP SCHEMA IF EXISTS test_c31b0c20bcdd;
DROP SCHEMA IF EXISTS test_bd064855bb8e;
DROP SCHEMA IF EXISTS test_b60e47a38b77;
DROP SCHEMA IF EXISTS test_af6d0450fcc0;
DROP SCHEMA IF EXISTS test_a8cef64b7ec2;
DROP SCHEMA IF EXISTS test_a4c109737b90;
DROP SCHEMA IF EXISTS test_9fb4554fd411;
DROP SCHEMA IF EXISTS test_9e6535311070;
DROP SCHEMA IF EXISTS test_96c800b3d5aa;
DROP SCHEMA IF EXISTS test_965e7127178b;
DROP SCHEMA IF EXISTS test_95155426c7b1;
DROP SCHEMA IF EXISTS test_7fcc08cfa565;
DROP SCHEMA IF EXISTS test_7e28d775a00f;
DROP SCHEMA IF EXISTS test_7d895a10951b;
DROP SCHEMA IF EXISTS test_7c007d613423;
DROP SCHEMA IF EXISTS test_6e153f2f1529;
DROP SCHEMA IF EXISTS test_6ac213cd3f06;
DROP SCHEMA IF EXISTS test_691897a28620;
DROP SCHEMA IF EXISTS test_617fd8b889fd;
DROP SCHEMA IF EXISTS test_5d9c4d843919;
DROP SCHEMA IF EXISTS test_5a137d1795ab;
DROP SCHEMA IF EXISTS test_59e85414e573;
DROP SCHEMA IF EXISTS test_5590380fa096;
DROP SCHEMA IF EXISTS test_54257caec79b;
DROP SCHEMA IF EXISTS test_4f7214c38b24;
DROP SCHEMA IF EXISTS test_49ef07dff10f;
DROP SCHEMA IF EXISTS test_474bbc1bc98d;
DROP SCHEMA IF EXISTS test_3b44c50b1101;
DROP SCHEMA IF EXISTS test_2f4c696ec2c9;
DROP SCHEMA IF EXISTS test_2a99c1350549;
DROP SCHEMA IF EXISTS test_26f1f2fec369;
DROP SCHEMA IF EXISTS test_1d1739625012;
DROP SCHEMA IF EXISTS test_18a0896ddd9f;
DROP SCHEMA IF EXISTS test_0be4849a5cf2;
DROP SCHEMA IF EXISTS test_0676c2332092;
DROP SCHEMA IF EXISTS test_00d95dbab1ec;
-- *not* dropping schema, since initdb creates it
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: test_00d95dbab1ec; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_00d95dbab1ec;


--
-- Name: test_0676c2332092; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_0676c2332092;


--
-- Name: test_0be4849a5cf2; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_0be4849a5cf2;


--
-- Name: test_18a0896ddd9f; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_18a0896ddd9f;


--
-- Name: test_1d1739625012; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_1d1739625012;


--
-- Name: test_26f1f2fec369; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_26f1f2fec369;


--
-- Name: test_2a99c1350549; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_2a99c1350549;


--
-- Name: test_2f4c696ec2c9; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_2f4c696ec2c9;


--
-- Name: test_3b44c50b1101; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_3b44c50b1101;


--
-- Name: test_474bbc1bc98d; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_474bbc1bc98d;


--
-- Name: test_49ef07dff10f; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_49ef07dff10f;


--
-- Name: test_4f7214c38b24; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_4f7214c38b24;


--
-- Name: test_54257caec79b; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_54257caec79b;


--
-- Name: test_5590380fa096; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_5590380fa096;


--
-- Name: test_59e85414e573; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_59e85414e573;


--
-- Name: test_5a137d1795ab; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_5a137d1795ab;


--
-- Name: test_5d9c4d843919; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_5d9c4d843919;


--
-- Name: test_617fd8b889fd; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_617fd8b889fd;


--
-- Name: test_691897a28620; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_691897a28620;


--
-- Name: test_6ac213cd3f06; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_6ac213cd3f06;


--
-- Name: test_6e153f2f1529; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_6e153f2f1529;


--
-- Name: test_7c007d613423; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_7c007d613423;


--
-- Name: test_7d895a10951b; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_7d895a10951b;


--
-- Name: test_7e28d775a00f; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_7e28d775a00f;


--
-- Name: test_7fcc08cfa565; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_7fcc08cfa565;


--
-- Name: test_95155426c7b1; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_95155426c7b1;


--
-- Name: test_965e7127178b; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_965e7127178b;


--
-- Name: test_96c800b3d5aa; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_96c800b3d5aa;


--
-- Name: test_9e6535311070; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_9e6535311070;


--
-- Name: test_9fb4554fd411; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_9fb4554fd411;


--
-- Name: test_a4c109737b90; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_a4c109737b90;


--
-- Name: test_a8cef64b7ec2; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_a8cef64b7ec2;


--
-- Name: test_af6d0450fcc0; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_af6d0450fcc0;


--
-- Name: test_b60e47a38b77; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_b60e47a38b77;


--
-- Name: test_bd064855bb8e; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_bd064855bb8e;


--
-- Name: test_c31b0c20bcdd; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_c31b0c20bcdd;


--
-- Name: test_ca17f2fa2e6a; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_ca17f2fa2e6a;


--
-- Name: test_cf9ccd7e5c54; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_cf9ccd7e5c54;


--
-- Name: test_d2437f804d5d; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_d2437f804d5d;


--
-- Name: test_e15ee6a5935a; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_e15ee6a5935a;


--
-- Name: test_e25f2b3f22e0; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_e25f2b3f22e0;


--
-- Name: test_e4af720996a9; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_e4af720996a9;


--
-- Name: test_e711a0eb0b15; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_e711a0eb0b15;


--
-- Name: test_eaf60fd28fc7; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_eaf60fd28fc7;


--
-- Name: test_ed1fb678ad44; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_ed1fb678ad44;


--
-- Name: test_f393c25cbbe3; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_f393c25cbbe3;


--
-- Name: test_ffb9edcd4eef; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA test_ffb9edcd4eef;


--
-- Name: auditpointrisk; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.auditpointrisk AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH'
);


--
-- Name: imagesetaction; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.imagesetaction AS ENUM (
    'BLOCK',
    'ALLOW',
    'REVIEW',
    'TAG'
);


--
-- Name: imagesetgroup; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.imagesetgroup AS ENUM (
    'SENSITIVE',
    'BRAND',
    'INDUSTRY',
    'COMPLIANCE',
    'INVENTORY',
    'KEYWORD',
    'CUSTOM'
);


--
-- Name: imagesetkind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.imagesetkind AS ENUM (
    'BLACKLIST',
    'WHITELIST'
);


--
-- Name: librarykind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.librarykind AS ENUM (
    '黑名单',
    '白名单'
);


--
-- Name: librarytype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.librarytype AS ENUM (
    'word',
    'image',
    'reply'
);


--
-- Name: machinestatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.machinestatus AS ENUM (
    'PENDING',
    'RUNNING',
    'COMPLETED',
    'FAILED'
);


--
-- Name: materialstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.materialstatus AS ENUM (
    'DRAFT',
    'SUBMITTED',
    'IN_REVIEW',
    'APPROVED',
    'REJECTED',
    'WITHDRAWN',
    'DESENSITIZED'
);


--
-- Name: materialtype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.materialtype AS ENUM (
    'IMAGE',
    'VIDEO',
    'PDF',
    'TEXT'
);


--
-- Name: packagestatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.packagestatus AS ENUM (
    'DRAFT',
    'SUBMITTED',
    'IN_REVIEW',
    'COMPLETED'
);


--
-- Name: reviewdecision; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.reviewdecision AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED',
    'RETURNED',
    'CANCELED'
);


--
-- Name: reviewtype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.reviewtype AS ENUM (
    'MACHINE',
    'HUMAN'
);


--
-- Name: servicescope; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.servicescope AS ENUM (
    'BUSINESS',
    'SPECIAL',
    'AIGC',
    'BAILIAN',
    'GENERAL'
);


--
-- Name: strategyscope; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.strategyscope AS ENUM (
    'DEFAULT',
    'GENERAL'
);


--
-- Name: tagcategory; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.tagcategory AS ENUM (
    'FIGURE',
    'EVENT',
    'ORGANIZATION',
    'SYMBOL',
    'CLAIM',
    'SLOGAN',
    'SCENE',
    'PRODUCT',
    'PRICE',
    'ABSOLUTE_TERM',
    'CREDENTIAL',
    'CUSTOM'
);


--
-- Name: tagdomain; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.tagdomain AS ENUM (
    'POLITICS',
    'PORN',
    'VIOLENCE',
    'ADS_LAW',
    'MEDICAL',
    'FINANCE',
    'MINOR',
    'PRIVACY',
    'IP',
    'GAMBLING',
    'FRAUD',
    'CUSTOM'
);


--
-- Name: tagstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.tagstatus AS ENUM (
    'DRAFT',
    'ACTIVE',
    'DEPRECATED'
);


--
-- Name: userrole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.userrole AS ENUM (
    'SUBMITTER',
    'REVIEWER',
    'MLR',
    'ADMIN',
    'SUPERADMIN'
);


--
-- Name: wordsetaction; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.wordsetaction AS ENUM (
    'BLOCK',
    'ALLOW',
    'REVIEW',
    'TAG'
);


--
-- Name: wordsetgroup; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.wordsetgroup AS ENUM (
    'SENSITIVE',
    'AD',
    'BRAND',
    'INDUSTRY',
    'COMPLIANCE',
    'KEYWORD',
    'INVENTORY',
    'CUSTOM'
);


--
-- Name: wordsetkind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.wordsetkind AS ENUM (
    'BLACKLIST',
    'WHITELIST'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: alert_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_events (
    id integer NOT NULL,
    rule_code character varying(64) NOT NULL,
    severity character varying(16) NOT NULL,
    metric character varying(64) NOT NULL,
    window_start timestamp with time zone NOT NULL,
    window_end timestamp with time zone NOT NULL,
    observed_value double precision NOT NULL,
    threshold double precision NOT NULL,
    dimension jsonb NOT NULL,
    detail jsonb NOT NULL,
    status character varying(16) NOT NULL,
    ack_by integer,
    ack_at timestamp with time zone,
    ack_note text,
    notified boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    public_id character varying(36)
);


--
-- Name: alert_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.alert_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: alert_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.alert_events_id_seq OWNED BY public.alert_events.id;


--
-- Name: annotations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.annotations (
    id integer NOT NULL,
    material_version_id integer NOT NULL,
    author_id integer NOT NULL,
    page integer,
    frame integer,
    timestamp_ms integer,
    x double precision,
    y double precision,
    w double precision,
    h double precision,
    shape jsonb,
    quote text,
    body text NOT NULL,
    parent_id integer,
    resolved boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    public_id character varying(36)
);


--
-- Name: annotations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.annotations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: annotations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.annotations_id_seq OWNED BY public.annotations.id;


--
-- Name: audit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_events (
    id integer NOT NULL,
    actor_id integer,
    action character varying(64) NOT NULL,
    entity_type character varying(64) NOT NULL,
    entity_id integer NOT NULL,
    payload jsonb NOT NULL,
    ip_address character varying(64),
    user_agent character varying(512),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    public_id character varying(36)
);


--
-- Name: audit_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_events_id_seq OWNED BY public.audit_events.id;


--
-- Name: audit_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_items (
    id integer NOT NULL,
    package_code character varying(64) NOT NULL,
    code character varying(64) NOT NULL,
    name_cn character varying(64) NOT NULL,
    aliases jsonb NOT NULL,
    description text,
    sort_order integer NOT NULL,
    is_enabled boolean NOT NULL,
    is_builtin boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    public_id character varying(36)
);


--
-- Name: audit_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_items_id_seq OWNED BY public.audit_items.id;


--
-- Name: audit_point_libraries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_point_libraries (
    audit_point_id integer NOT NULL,
    library_id integer NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_points (
    id integer NOT NULL,
    package_code character varying(64) NOT NULL,
    item_id integer NOT NULL,
    code character varying(64) NOT NULL,
    label character varying(128) NOT NULL,
    label_cn character varying(64) NOT NULL,
    description text,
    medium_threshold double precision NOT NULL,
    high_threshold double precision NOT NULL,
    scope_text character varying(255),
    risk_level public.auditpointrisk NOT NULL,
    is_enabled boolean NOT NULL,
    is_builtin boolean DEFAULT false NOT NULL,
    custom_wordset_id integer,
    custom_library_id integer,
    custom_reply_library_id integer,
    sort_order integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    public_id character varying(36)
);


--
-- Name: audit_points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_points_id_seq OWNED BY public.audit_points.id;


--
-- Name: detection_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.detection_rules (
    id integer NOT NULL,
    service_code character varying(64) NOT NULL,
    label character varying(128) NOT NULL,
    label_cn character varying(64) NOT NULL,
    description text,
    medium_threshold double precision NOT NULL,
    high_threshold double precision NOT NULL,
    scope_text character varying(255),
    is_enabled boolean NOT NULL,
    custom_wordset_id integer,
    audit_point_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    public_id character varying(36)
);


--
-- Name: detection_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.detection_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: detection_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.detection_rules_id_seq OWNED BY public.detection_rules.id;


--
-- Name: disposition_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.disposition_rules (
    id integer NOT NULL,
    public_id character varying(36) NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    description text,
    is_enabled boolean DEFAULT false NOT NULL,
    risk_levels text[] DEFAULT '{}'::text[] NOT NULL,
    sensitive_levels text[] DEFAULT '{}'::text[] NOT NULL,
    review_rule_id integer,
    sample_ratio numeric(5,2) DEFAULT 100.0,
    auto_action_overrides jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_builtin boolean DEFAULT false NOT NULL,
    is_editable boolean DEFAULT true NOT NULL,
    locked_by_id integer,
    locked_at timestamp with time zone,
    created_by_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: disposition_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.disposition_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: disposition_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.disposition_rules_id_seq OWNED BY public.disposition_rules.id;


--
-- Name: human_review_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.human_review_configs (
    id integer NOT NULL,
    service_code character varying(64) NOT NULL,
    is_enabled boolean NOT NULL,
    risk_levels character varying(255) NOT NULL,
    review_rule_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    public_id character varying(36)
);


--
-- Name: human_review_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.human_review_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: human_review_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.human_review_configs_id_seq OWNED BY public.human_review_configs.id;


--
-- Name: image_set_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.image_set_items (
    id integer NOT NULL,
    set_id integer NOT NULL,
    storage_key character varying(512) NOT NULL,
    original_filename character varying(255) NOT NULL,
    mime_type character varying(120) NOT NULL,
    file_size bigint NOT NULL,
    sha256 character varying(128),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    public_id character varying(36)
);


--
-- Name: image_set_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.image_set_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: image_set_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.image_set_items_id_seq OWNED BY public.image_set_items.id;


--
-- Name: image_sets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.image_sets (
    id integer NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    "group" public.imagesetgroup NOT NULL,
    action public.imagesetaction NOT NULL,
    kind public.imagesetkind,
    description text,
    is_active boolean NOT NULL,
    ignored_services jsonb NOT NULL,
    item_count integer NOT NULL,
    capacity integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    public_id character varying(36)
);


--
-- Name: image_sets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.image_sets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: image_sets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.image_sets_id_seq OWNED BY public.image_sets.id;


--
-- Name: libraries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.libraries (
    id integer NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    library_type public.librarytype NOT NULL,
    kind public.librarykind,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    is_platform boolean DEFAULT false NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp without time zone,
    ignored_services jsonb NOT NULL,
    effective_from timestamp with time zone,
    effective_until timestamp with time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    public_id character varying(36)
);


--
-- Name: libraries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.libraries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: libraries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.libraries_id_seq OWNED BY public.libraries.id;


--
-- Name: library_item_references; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.library_item_references (
    item_id integer NOT NULL,
    library_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: library_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.library_items (
    id integer NOT NULL,
    library_id integer NOT NULL,
    word character varying(256),
    trigger character varying(256),
    reply text,
    storage_key character varying(512),
    sha256 character varying(64),
    original_filename character varying(255),
    mime_type character varying(120),
    file_size bigint,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    public_id character varying(36),
    CONSTRAINT ck_library_items_kind_consistent CHECK (((word IS NOT NULL) OR (storage_key IS NOT NULL) OR (reply IS NOT NULL)))
);


--
-- Name: library_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.library_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: library_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.library_items_id_seq OWNED BY public.library_items.id;


--
-- Name: llm_calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.llm_calls (
    id integer NOT NULL,
    public_id character varying(36) NOT NULL,
    task_id integer,
    version_id integer,
    correlation_id character varying(64),
    model character varying(64),
    ok boolean NOT NULL,
    schema_valid boolean NOT NULL,
    truncated boolean NOT NULL,
    input_chars integer,
    token_in integer,
    token_out integer,
    latency_ms integer,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: llm_calls_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.llm_calls_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: llm_calls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.llm_calls_id_seq OWNED BY public.llm_calls.id;


--
-- Name: material_package_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.material_package_items (
    id integer NOT NULL,
    package_id integer NOT NULL,
    material_id integer NOT NULL,
    "position" integer NOT NULL,
    review_task_id integer,
    public_id character varying(36)
);


--
-- Name: material_package_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.material_package_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: material_package_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.material_package_items_id_seq OWNED BY public.material_package_items.id;


--
-- Name: material_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.material_packages (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    material_type character varying(16) NOT NULL,
    status public.packagestatus NOT NULL,
    creator_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    public_id character varying(36)
);


--
-- Name: material_packages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.material_packages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: material_packages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.material_packages_id_seq OWNED BY public.material_packages.id;


--
-- Name: material_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.material_versions (
    id integer NOT NULL,
    material_id integer NOT NULL,
    version_no integer NOT NULL,
    storage_key character varying(512) NOT NULL,
    original_filename character varying(255) NOT NULL,
    mime_type character varying(120) NOT NULL,
    file_size bigint NOT NULL,
    checksum character varying(128),
    text_body text,
    extra jsonb,
    created_by_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    public_id character varying(36)
);


--
-- Name: material_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.material_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: material_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.material_versions_id_seq OWNED BY public.material_versions.id;


--
-- Name: materials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.materials (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    material_type public.materialtype NOT NULL,
    status public.materialstatus NOT NULL,
    tags jsonb,
    metadata jsonb,
    submitter_id integer NOT NULL,
    current_version_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    public_id character varying(36)
);


--
-- Name: materials_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.materials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: materials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.materials_id_seq OWNED BY public.materials.id;


--
-- Name: ops_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ops_log (
    id integer NOT NULL,
    actor character varying(64) DEFAULT 'manual'::character varying NOT NULL,
    action character varying(128) NOT NULL,
    status character varying(32) NOT NULL,
    argv text,
    cwd text,
    detail json,
    message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    public_id character varying(36)
);


--
-- Name: ops_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ops_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ops_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ops_log_id_seq OWNED BY public.ops_log.id;


--
-- Name: review_assignment_audit_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.review_assignment_audit_items (
    id integer NOT NULL,
    public_id character varying(36) NOT NULL,
    assignment_id integer NOT NULL,
    audit_item_id integer NOT NULL,
    item_snapshot jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: review_assignment_audit_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.review_assignment_audit_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: review_assignment_audit_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.review_assignment_audit_items_id_seq OWNED BY public.review_assignment_audit_items.id;


--
-- Name: review_assignment_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.review_assignment_tags (
    id integer NOT NULL,
    assignment_id integer NOT NULL,
    tag_id character varying(36) NOT NULL,
    tag_snapshot jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    public_id character varying(36)
);


--
-- Name: review_assignment_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.review_assignment_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: review_assignment_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.review_assignment_tags_id_seq OWNED BY public.review_assignment_tags.id;


--
-- Name: review_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.review_assignments (
    id integer NOT NULL,
    task_id integer NOT NULL,
    assignee_id integer NOT NULL,
    decision public.reviewdecision NOT NULL,
    note text,
    decided_at timestamp with time zone,
    public_id character varying(36)
);


--
-- Name: review_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.review_assignments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: review_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.review_assignments_id_seq OWNED BY public.review_assignments.id;


--
-- Name: review_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.review_tasks (
    id integer NOT NULL,
    material_id integer NOT NULL,
    material_version_id integer NOT NULL,
    workflow_instance_id integer NOT NULL,
    stage_key character varying(64) NOT NULL,
    title character varying(255) NOT NULL,
    review_type public.reviewtype NOT NULL,
    final_decision public.reviewdecision NOT NULL,
    machine_status public.machinestatus,
    machine_result jsonb,
    machine_started_at timestamp with time zone,
    machine_completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    canceled_at timestamp with time zone,
    canceled_by integer,
    cancel_reason character varying(500),
    public_id character varying(36)
);


--
-- Name: review_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.review_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: review_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.review_tasks_id_seq OWNED BY public.review_tasks.id;


--
-- Name: rule_sets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rule_sets (
    id integer NOT NULL,
    public_id character varying(36) NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    description text,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_builtin boolean DEFAULT false NOT NULL,
    is_editable boolean DEFAULT true NOT NULL,
    locked_by_id integer,
    locked_at timestamp with time zone,
    created_by_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: rule_sets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rule_sets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rule_sets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rule_sets_id_seq OWNED BY public.rule_sets.id;


--
-- Name: service_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_categories (
    id integer NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    description text,
    is_system boolean NOT NULL,
    sort_order integer NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    public_id character varying(36)
);


--
-- Name: service_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_categories_id_seq OWNED BY public.service_categories.id;


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id integer NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    scope public.servicescope NOT NULL,
    description text,
    is_active boolean NOT NULL,
    is_custom boolean NOT NULL,
    is_rule_package boolean NOT NULL,
    category_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    public_id character varying(36)
);


--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.services_id_seq OWNED BY public.services.id;


--
-- Name: strategies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strategies (
    id integer NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    scope public.strategyscope NOT NULL,
    description text,
    is_active boolean NOT NULL,
    effective_from timestamp with time zone,
    effective_until timestamp with time zone,
    definition jsonb,
    service_config jsonb,
    created_by_id integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    public_id character varying(36),
    rule_set_id integer,
    disposition_rule_id integer
);


--
-- Name: strategies_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strategies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strategies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strategies_id_seq OWNED BY public.strategies.id;


--
-- Name: strategy_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strategy_items (
    id integer NOT NULL,
    strategy_id integer NOT NULL,
    media_type character varying(16) NOT NULL,
    item_id integer NOT NULL,
    is_enabled boolean NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    public_id character varying(36)
);


--
-- Name: strategy_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strategy_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strategy_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strategy_items_id_seq OWNED BY public.strategy_items.id;


--
-- Name: strategy_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strategy_points (
    id integer NOT NULL,
    strategy_id integer NOT NULL,
    media_type character varying(16) NOT NULL,
    item_id integer NOT NULL,
    point_id integer NOT NULL,
    is_enabled boolean NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    public_id character varying(36)
);


--
-- Name: strategy_points_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strategy_points_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strategy_points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strategy_points_id_seq OWNED BY public.strategy_points.id;


--
-- Name: strategy_points_v2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.strategy_points_v2 (
    id integer NOT NULL,
    public_id character varying(36) NOT NULL,
    rule_set_id integer NOT NULL,
    media_type character varying(16) NOT NULL,
    item_id integer NOT NULL,
    point_id integer NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    medium_threshold numeric(5,2),
    high_threshold numeric(5,2),
    linked_library_ids integer[],
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: strategy_points_v2_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.strategy_points_v2_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: strategy_points_v2_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.strategy_points_v2_id_seq OWNED BY public.strategy_points_v2.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    id character varying(36) NOT NULL,
    code character varying(96) NOT NULL,
    name character varying(128) NOT NULL,
    name_en character varying(128),
    description text,
    domain public.tagdomain NOT NULL,
    category public.tagcategory NOT NULL,
    jurisdictions jsonb NOT NULL,
    industries jsonb NOT NULL,
    channels jsonb NOT NULL,
    knowledge_refs jsonb NOT NULL,
    evidence_refs jsonb NOT NULL,
    status public.tagstatus NOT NULL,
    version integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    deleted_at timestamp without time zone
);


--
-- Name: trigger_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trigger_runs (
    id integer NOT NULL,
    trigger_id integer NOT NULL,
    source character varying(32) NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    status character varying(32),
    scanned_count integer NOT NULL,
    created_count integer NOT NULL,
    skipped_count integer NOT NULL,
    failed_count integer NOT NULL,
    error text,
    details jsonb,
    public_id character varying(36)
);


--
-- Name: trigger_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trigger_runs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trigger_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.trigger_runs_id_seq OWNED BY public.trigger_runs.id;


--
-- Name: triggers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.triggers (
    id integer NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    trigger_type character varying(32) NOT NULL,
    is_enabled boolean NOT NULL,
    spec jsonb NOT NULL,
    workflow_template_code character varying(64),
    strategy_id integer,
    match_conditions jsonb NOT NULL,
    override_human_review jsonb,
    scan_interval_sec integer NOT NULL,
    last_run_at timestamp with time zone,
    next_run_at timestamp with time zone,
    run_count integer NOT NULL,
    last_error text,
    created_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    public_id character varying(36)
);


--
-- Name: triggers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.triggers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: triggers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.triggers_id_seq OWNED BY public.triggers.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    full_name character varying(128) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    role public.userrole NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    public_id character varying(36)
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: word_sets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.word_sets (
    id integer NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    "group" public.wordsetgroup NOT NULL,
    action public.wordsetaction NOT NULL,
    kind public.wordsetkind,
    words_text text,
    description text,
    is_active boolean NOT NULL,
    ignored_services jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone,
    public_id character varying(36)
);


--
-- Name: word_sets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.word_sets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: word_sets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.word_sets_id_seq OWNED BY public.word_sets.id;


--
-- Name: workflow_instances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_instances (
    id integer NOT NULL,
    material_id integer NOT NULL,
    material_version_id integer NOT NULL,
    template_id integer NOT NULL,
    state character varying(32) NOT NULL,
    current_stage_key character varying(64),
    strategy_human_review jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    public_id character varying(36)
);


--
-- Name: workflow_instances_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.workflow_instances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workflow_instances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.workflow_instances_id_seq OWNED BY public.workflow_instances.id;


--
-- Name: workflow_nodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_nodes (
    id integer NOT NULL,
    instance_id integer NOT NULL,
    "position" integer NOT NULL,
    stage_key character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    required_role character varying(32) NOT NULL,
    mode character varying(16) NOT NULL,
    node_type character varying(16) NOT NULL,
    status character varying(32) NOT NULL,
    public_id character varying(36)
);


--
-- Name: workflow_nodes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.workflow_nodes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workflow_nodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.workflow_nodes_id_seq OWNED BY public.workflow_nodes.id;


--
-- Name: workflow_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_templates (
    id integer NOT NULL,
    code character varying(64) NOT NULL,
    name character varying(128) NOT NULL,
    description text,
    definition jsonb NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    public_id character varying(36)
);


--
-- Name: workflow_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.workflow_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workflow_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.workflow_templates_id_seq OWNED BY public.workflow_templates.id;


--
-- Name: alert_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_events ALTER COLUMN id SET DEFAULT nextval('public.alert_events_id_seq'::regclass);


--
-- Name: annotations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.annotations ALTER COLUMN id SET DEFAULT nextval('public.annotations_id_seq'::regclass);


--
-- Name: audit_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events ALTER COLUMN id SET DEFAULT nextval('public.audit_events_id_seq'::regclass);


--
-- Name: audit_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_items ALTER COLUMN id SET DEFAULT nextval('public.audit_items_id_seq'::regclass);


--
-- Name: audit_points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_points ALTER COLUMN id SET DEFAULT nextval('public.audit_points_id_seq'::regclass);


--
-- Name: detection_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detection_rules ALTER COLUMN id SET DEFAULT nextval('public.detection_rules_id_seq'::regclass);


--
-- Name: disposition_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disposition_rules ALTER COLUMN id SET DEFAULT nextval('public.disposition_rules_id_seq'::regclass);


--
-- Name: human_review_configs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.human_review_configs ALTER COLUMN id SET DEFAULT nextval('public.human_review_configs_id_seq'::regclass);


--
-- Name: image_set_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.image_set_items ALTER COLUMN id SET DEFAULT nextval('public.image_set_items_id_seq'::regclass);


--
-- Name: image_sets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.image_sets ALTER COLUMN id SET DEFAULT nextval('public.image_sets_id_seq'::regclass);


--
-- Name: libraries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.libraries ALTER COLUMN id SET DEFAULT nextval('public.libraries_id_seq'::regclass);


--
-- Name: library_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_items ALTER COLUMN id SET DEFAULT nextval('public.library_items_id_seq'::regclass);


--
-- Name: llm_calls id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_calls ALTER COLUMN id SET DEFAULT nextval('public.llm_calls_id_seq'::regclass);


--
-- Name: material_package_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_package_items ALTER COLUMN id SET DEFAULT nextval('public.material_package_items_id_seq'::regclass);


--
-- Name: material_packages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_packages ALTER COLUMN id SET DEFAULT nextval('public.material_packages_id_seq'::regclass);


--
-- Name: material_versions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_versions ALTER COLUMN id SET DEFAULT nextval('public.material_versions_id_seq'::regclass);


--
-- Name: materials id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.materials ALTER COLUMN id SET DEFAULT nextval('public.materials_id_seq'::regclass);


--
-- Name: ops_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ops_log ALTER COLUMN id SET DEFAULT nextval('public.ops_log_id_seq'::regclass);


--
-- Name: review_assignment_audit_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_assignment_audit_items ALTER COLUMN id SET DEFAULT nextval('public.review_assignment_audit_items_id_seq'::regclass);


--
-- Name: review_assignment_tags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_assignment_tags ALTER COLUMN id SET DEFAULT nextval('public.review_assignment_tags_id_seq'::regclass);


--
-- Name: review_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_assignments ALTER COLUMN id SET DEFAULT nextval('public.review_assignments_id_seq'::regclass);


--
-- Name: review_tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_tasks ALTER COLUMN id SET DEFAULT nextval('public.review_tasks_id_seq'::regclass);


--
-- Name: rule_sets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_sets ALTER COLUMN id SET DEFAULT nextval('public.rule_sets_id_seq'::regclass);


--
-- Name: service_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_categories ALTER COLUMN id SET DEFAULT nextval('public.service_categories_id_seq'::regclass);


--
-- Name: services id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services ALTER COLUMN id SET DEFAULT nextval('public.services_id_seq'::regclass);


--
-- Name: strategies id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategies ALTER COLUMN id SET DEFAULT nextval('public.strategies_id_seq'::regclass);


--
-- Name: strategy_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_items ALTER COLUMN id SET DEFAULT nextval('public.strategy_items_id_seq'::regclass);


--
-- Name: strategy_points id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_points ALTER COLUMN id SET DEFAULT nextval('public.strategy_points_id_seq'::regclass);


--
-- Name: strategy_points_v2 id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_points_v2 ALTER COLUMN id SET DEFAULT nextval('public.strategy_points_v2_id_seq'::regclass);


--
-- Name: trigger_runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trigger_runs ALTER COLUMN id SET DEFAULT nextval('public.trigger_runs_id_seq'::regclass);


--
-- Name: triggers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.triggers ALTER COLUMN id SET DEFAULT nextval('public.triggers_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: word_sets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.word_sets ALTER COLUMN id SET DEFAULT nextval('public.word_sets_id_seq'::regclass);


--
-- Name: workflow_instances id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_instances ALTER COLUMN id SET DEFAULT nextval('public.workflow_instances_id_seq'::regclass);


--
-- Name: workflow_nodes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_nodes ALTER COLUMN id SET DEFAULT nextval('public.workflow_nodes_id_seq'::regclass);


--
-- Name: workflow_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_templates ALTER COLUMN id SET DEFAULT nextval('public.workflow_templates_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
20260716_review_detail_cleanup
\.


--
-- Data for Name: alert_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_events (id, rule_code, severity, metric, window_start, window_end, observed_value, threshold, dimension, detail, status, ack_by, ack_at, ack_note, notified, created_at, public_id) FROM stdin;
1	reject_rate_spike	warn	reject_rate	2026-07-13 04:46:54.546401+08	2026-07-13 05:16:54.546401+08	8.4	3	{}	{"note": "近 30 分钟拒绝率较上一 30 分钟上升 8.4pp, 集中在 '极限用语' 类素材", "source": "seed_analytics_demo", "current_submitted": 89, "previous_submitted": 78, "current_reject_rate": 22.5, "previous_reject_rate": 14.1}	open	\N	\N	\N	f	2026-07-13 05:16:54.548613+08	019f5830-b394-75e0-adef-c0099db3b4e5
2	high_risk_concentration	warn	distinct_rejected_submitters	2026-07-13 04:16:54.546401+08	2026-07-13 05:16:54.546401+08	7	5	{}	{"note": "过去 1 小时有 7 个不同提交者产生拒绝, 超过阈值", "source": "seed_analytics_demo", "current_rejected": 31, "current_submitted": 142}	open	\N	\N	\N	f	2026-07-13 05:16:54.548613+08	019f5830-b394-75e0-adef-c00a04495db6
3	submit_drop	info	submitted	2026-07-13 04:16:54.546401+08	2026-07-13 05:16:54.546401+08	42	110	{}	{"note": "提交量较上一小时下降 61.8%, 建议检查上游入口", "source": "seed_analytics_demo", "drop_pct": 61.82, "current_submitted": 42, "previous_submitted": 110}	acknowledged	\N	\N	\N	f	2026-07-13 05:16:54.548613+08	019f5830-b398-7274-9150-52c0f5047e84
\.


--
-- Data for Name: annotations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.annotations (id, material_version_id, author_id, page, frame, timestamp_ms, x, y, w, h, shape, quote, body, parent_id, resolved, created_at, updated_at, public_id) FROM stdin;
\.


--
-- Data for Name: audit_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_events (id, actor_id, action, entity_type, entity_id, payload, ip_address, user_agent, created_at, public_id) FROM stdin;
1	1	material.create	material	1	{"type": "text"}	\N	\N	2026-07-12 16:56:14.536255+08	3b97d31b-4a63-4c41-86e0-67ffcd661a6a
2	1	material.version.upload	material	1	{"size": 9, "version_id": 1}	\N	\N	2026-07-12 16:56:14.588454+08	2ac81b88-22bb-48a1-ae25-43f70dccac54
3	1	workflow.start	workflow_instance	1	{"template": "hybrid", "material_id": 1, "strategy_id": null, "force_human_rules": [], "skip_machine_review": false}	\N	\N	2026-07-12 16:56:14.615336+08	2e4b87b4-b875-473f-84b4-e5a395dbaa64
4	1	material.create	material	2	{"type": "text"}	\N	\N	2026-07-12 17:04:08.326529+08	3c6d1e37-5d38-4774-bb08-7690df699711
5	1	material.version.upload	material	2	{"size": 9, "version_id": 2}	\N	\N	2026-07-12 17:04:08.358327+08	181e5e46-8296-4193-a9ff-df8e25536777
6	1	workflow.start	workflow_instance	2	{"template": "hybrid", "material_id": 2, "strategy_id": null, "force_human_rules": [], "skip_machine_review": false}	\N	\N	2026-07-12 17:04:08.380276+08	e9e34688-0e62-4d58-870e-e323bc045054
7	5	strategy.create	strategy	2	{"code": "2", "scope": "general", "enabled_item_count": 0, "enabled_point_count": 1, "human_review_enabled": false}	\N	\N	2026-07-12 22:05:13.635187+08	3e754306-9764-4bf2-84d5-381dc4886dce
8	5	strategy.create	strategy	3	{"code": "3", "scope": "general", "enabled_item_count": 0, "enabled_point_count": 1, "human_review_enabled": false}	\N	\N	2026-07-12 22:06:03.277406+08	a46a9976-9577-4a2c-872d-cdb9472bdb3b
9	5	material.create	material	3	{"type": "text"}	\N	\N	2026-07-12 23:25:14.303873+08	a5beab62-e9cd-42f5-a2bd-3609dde32143
10	5	material.version.upload	material	3	{"size": 9, "version_id": 3}	\N	\N	2026-07-12 23:25:14.355109+08	73c7c72d-660e-4a60-a881-94d1dbe5f7ce
11	5	workflow.start	workflow_instance	3	{"template": "hybrid", "material_id": 3, "strategy_id": null, "force_human_rules": [], "skip_machine_review": false}	\N	\N	2026-07-12 23:25:14.383935+08	fb710458-a175-44e2-a291-523eb3266b62
12	5	strategy.delete	strategy	3	{"code": "3"}	\N	\N	2026-07-13 00:59:31.992293+08	b07eb4dc-f821-4287-b915-a7d50b729bdd
13	5	material.create	material	4	{"type": "text"}	\N	\N	2026-07-13 02:13:18.241137+08	1629fba5-519f-483c-a873-7051dd74b91c
14	5	material.version.upload	material	4	{"size": 9, "version_id": 4}	\N	\N	2026-07-13 02:13:18.271243+08	e0f5098d-d9f8-4b8c-b8cf-ae4eb1c20535
15	5	workflow.start	workflow_instance	4	{"template": "hybrid", "material_id": 4, "strategy_id": null, "force_human_rules": [], "skip_machine_review": false}	\N	\N	2026-07-13 02:13:18.292781+08	ec06126f-8452-4674-b861-f6b21f93d81e
16	5	material.create	material	5	{"type": "text"}	\N	\N	2026-07-13 02:50:00.445572+08	a1e8e998-f7dd-4187-b66a-71996acea3b6
17	5	material.version.upload	material	5	{"size": 4, "version_id": 5}	\N	\N	2026-07-13 02:50:00.474899+08	68d6c29e-f904-487c-886c-c28d7b3b6bce
18	5	workflow.start	workflow_instance	5	{"template": "hybrid", "material_id": 5, "strategy_id": null, "force_human_rules": [], "skip_machine_review": false}	\N	\N	2026-07-13 02:50:00.496667+08	2ffc27e8-2a78-4424-8755-9944f6310792
19	\N	workflow.approved	workflow_instance	1	{"final_stage": "ai_scan"}	\N	\N	2026-07-13 05:12:36.36036+08	019f582c-c322-77ae-8e9e-8f2583c85878
\.


--
-- Data for Name: audit_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_items (id, package_code, code, name_cn, aliases, description, sort_order, is_enabled, is_builtin, created_at, updated_at, public_id) FROM stdin;
1	ad_compliance_detection_pro	pt_water_mark	水印	["水印", "logo", "watermark"]	识别画面中的网络社交平台、品牌方等水印信息	0	t	t	2026-07-12 16:30:57.31123	\N	76ab98ee-23f9-466d-9253-89f7e9eae808
4	image_audit_pro	img_politics	涉政	["涉政", "政治敏感", "politics"]	识别政治人物、政治事件、政治符号等涉政内容	0	t	t	2026-07-12 16:30:57.31123	\N	35a48485-b6a1-42fd-93b7-a9278fb8b073
2	ad_compliance_detection_pro	pt_qr_code	二维码	["二维码", "qrcode", "QR码", "小程序码"]	识别画面中的二维码、QR 码、小程序码等	0	t	t	2026-07-12 16:30:57.31123	\N	41f51201-27e2-40ca-b29d-fab4527e82c8
3	ad_compliance_detection_pro	pt_drainage	引流	["引流", "联系方式", "兼职招聘", "办证", "投资理财"]	识别画面中的联系方式、兼职招聘、办证、投资理财等引流内容	0	t	t	2026-07-12 16:30:57.31123	\N	676694cf-6bc7-4127-98ee-d90e5c78ebfd
5	image_audit_pro	img_porn	涉黄	["涉黄", "色情", "porn", "低俗"]	识别色情、低俗、裸露等涉黄内容	0	t	t	2026-07-12 16:30:57.31123	\N	4f7d1e24-3119-4c39-80f5-6ab8d8008833
6	image_audit_pro	img_violence	涉暴	["涉暴", "暴力", "血腥", "violence"]	识别血腥、暴力、残忍等涉暴内容	0	t	t	2026-07-12 16:30:57.31123	\N	65381393-905a-46c6-9bb8-4beb3671565c
7	image_audit_pro	img_prohibited	违禁	["违禁", "毒品", "赌博", "prohibited"]	识别毒品、赌博、违禁品等违禁内容	0	t	t	2026-07-12 16:30:57.31123	\N	e33848c5-22c5-407e-a781-a76cfcacd9be
8	image_audit_pro	img_terrorism	暴恐	["暴恐", "恐怖", "terrorism"]	识别恐怖组织、恐怖袭击等暴恐内容	0	t	t	2026-07-12 16:30:57.31123	\N	daa5077b-6a0c-48dd-9fde-9695da32d2a2
9	image_audit_pro	img_ad	广告	["广告", "advertisement"]	识别画面中的第三方广告、品牌植入	0	t	t	2026-07-12 16:30:57.31123	\N	72b3450e-80a4-4580-ab80-721cc0726fc0
10	image_audit_pro	img_adlaw	广告法	["广告法", "极限用语", "adlaw"]	识别极限用语、虚假承诺等广告法违规内容	0	t	t	2026-07-12 16:30:57.31123	\N	cda24f38-97a1-4c7a-a706-f7292b013520
11	image_audit_pro	img_religion	宗教	["宗教", "religion"]	识别宗教极端、宗教渗透等宗教敏感内容	0	t	t	2026-07-12 16:30:57.31123	\N	27fc0716-240c-47ef-acff-b5d688dae083
12	image_audit_pro	img_special	专项	["专项", "special"]	专项审核场景	0	t	t	2026-07-12 16:30:57.31123	\N	cd325f9c-27aa-4e6a-9952-3fb544f49bdf
13	text_audit_pro	tx_politics	涉政	["涉政", "政治敏感", "politics"]	识别政治敏感文本	0	t	t	2026-07-12 16:30:57.31123	\N	1f1d03cf-4064-404d-99eb-e4cf43e7da72
14	text_audit_pro	tx_terrorism	暴恐	["暴恐", "恐怖", "terrorism"]	识别恐怖组织、恐怖袭击等暴恐文本	0	t	t	2026-07-12 16:30:57.31123	\N	2d76f030-b20e-44d0-8a36-7b807540d2c0
15	text_audit_pro	tx_porn	色情	["色情", "低俗", "porn"]	识别色情、低俗文本	0	t	t	2026-07-12 16:30:57.31123	\N	48e46a87-0181-4a19-aa9a-d9c5c5debdb7
16	text_audit_pro	tx_advertising	广告法	["广告法", "极限用语"]	识别广告法违规表述（极限用语、虚假承诺）	0	t	t	2026-07-12 16:30:57.31123	\N	8eadfbc9-56d4-43b6-b47e-ad13174cff6a
17	text_audit_pro	tx_abuse	辱骂	["辱骂", "谩骂", "abuse"]	识别辱骂、人身攻击文本	0	t	t	2026-07-12 16:30:57.31123	\N	de37919e-b154-48ba-a71c-b061297e2c72
18	text_audit_pro	tx_vulgar	低俗	["低俗", "vulgar"]	识别低俗口头语、不文明用语	0	t	t	2026-07-12 16:30:57.31123	\N	fffa9f4e-e5b9-462f-90a3-dffcb3b9684a
19	text_audit_pro	tx_minor_protection	未成年保护	["未成年", "minor"]	识别涉及未成年人的不良内容	0	t	t	2026-07-12 16:30:57.31123	\N	2bfb3d65-987c-42e8-b262-e491b580298d
20	text_audit_pro	tx_values	价值观	["价值观", "values"]	识别违反主流价值观的内容	0	t	t	2026-07-12 16:30:57.31123	\N	16e99900-6b20-4b8e-825a-cdcd8625b532
21	text_audit_pro	tx_illegal	违法违规	["违法", "illegal"]	识别违法违规文本	0	t	t	2026-07-12 16:30:57.31123	\N	bed42822-604f-45ad-97b3-024028d647a7
22	text_audit_pro	tx_privacy	隐私信息	["隐私", "个人信息", "privacy"]	识别个人隐私信息泄露	0	t	t	2026-07-12 16:30:57.31123	\N	02b5180f-c95c-410b-afac-c7cefc625a12
23	text_audit_pro	tx_promptattack	prompt攻击	["prompt", "jailbreak"]	识别 prompt 注入、越狱攻击	0	t	t	2026-07-12 16:30:57.31123	\N	5ad34ee8-8622-4de3-a896-a166dfbf5aa2
24	text_audit_pro	bad	不良	["不良内容", "未成年不适", "偏见歧视", "不良价值观", "攻击辱骂", "低俗口头语", "封建迷信", "灌水", "spam"]	聚合识别不良内容（未成年不适、偏见歧视、不良价值观、攻击辱骂、低俗口头语、封建迷信、灌水）	0	t	t	2026-07-12 16:30:57.31123	\N	91bc6e9b-c78f-420f-922a-1345408395b0
25	audio_audit_pro	au_politics	涉政	["涉政", "politics"]	识别语音中的政治敏感内容	0	t	t	2026-07-12 16:30:57.31123	\N	577c632e-9df7-4443-b39c-ff082daed66c
26	audio_audit_pro	au_porn	色情	["色情", "porn"]	识别语音中的色情内容	0	t	t	2026-07-12 16:30:57.31123	\N	53dfd969-af9c-4676-a799-2f2e2f8dde66
27	audio_audit_pro	au_violence	暴恐	["暴恐", "terrorism"]	识别语音中的暴恐内容	0	t	t	2026-07-12 16:30:57.31123	\N	a1d82f96-419c-49de-ab49-e5c6e44f39d8
28	audio_audit_pro	au_adlaw	广告法	["广告法", "adlaw"]	识别语音中的广告法违规词	0	t	t	2026-07-12 16:30:57.31123	\N	7798a0a2-b44c-496f-8c65-1c698773955e
29	audio_audit_pro	au_abuse	辱骂	["辱骂", "abuse"]	识别语音中的辱骂内容	0	t	t	2026-07-12 16:30:57.31123	\N	8b9088e3-ec38-4906-a5db-fd1f933e2012
30	audio_audit_pro	au_minor	未成年保护	["未成年", "minor"]	识别语音中涉及未成年人的不良内容	0	t	t	2026-07-12 16:30:57.31123	\N	28b9e8a9-555c-4728-bb55-e20b571b8faa
31	audio_audit_pro	au_illegal	违法违规	["违法", "illegal"]	识别语音中的违法违规内容	0	t	t	2026-07-12 16:30:57.31123	\N	4efaea36-bb11-4d92-b3c6-6f245b69cff1
32	audio_audit_pro	au_voiceprint	声纹检测	["声纹", "voiceprint"]	识别声纹特征（如娇喘等异常发声模式）	0	t	t	2026-07-12 16:30:57.31123	\N	adc367fc-2293-466b-b832-93aadf4766c1
33	audio_audit_pro	au_audiopquality	音频质量	["音频质量", "audio_quality"]	识别音频质量（如无语音内容、静音等）	0	t	t	2026-07-12 16:30:57.31123	\N	4f6781d7-0163-4f76-a913-3b02608dc8c8
34	document_audit_pro	doc_image	图片内容	["图片内容", "图片审核"]	识别文档中的图片内容（复用图片审核规则）	0	t	t	2026-07-12 16:30:57.31123	\N	69879fe2-4b39-456b-b798-35b679024b5b
35	document_audit_pro	doc_text	文本内容	["文本内容", "文本审核"]	识别文档中的文本内容（复用文本审核规则）	0	t	t	2026-07-12 16:30:57.31123	\N	0eab456f-5e44-4aa9-9327-622b862abaa6
36	document_audit_pro	doc_sensitive	敏感信息	["敏感", "sensitive"]	识别文档中的敏感信息	0	t	t	2026-07-12 16:30:57.31123	\N	25b958a4-debb-435c-92f7-427453c7c2e4
37	document_audit_pro	doc_illegal	违法违规	["违法", "illegal"]	识别文档中的违法违规内容	0	t	t	2026-07-12 16:30:57.31123	\N	2556c4bd-7e2a-4f6f-8bed-86555ac36a42
38	video_audit_pro	vid_frame	画面内容	["画面内容", "图片审核"]	识别视频画面内容（复用图片审核规则）	0	t	t	2026-07-12 16:30:57.31123	\N	eb5ebc07-7986-4717-a7ec-a4e3ee291c26
39	video_audit_pro	vid_audio	音轨内容	["音轨内容", "语音审核"]	识别视频音轨内容（复用语音审核规则）	0	t	t	2026-07-12 16:30:57.31123	\N	9441d004-a36f-4db0-91ac-ede2b68c2f35
40	video_audit_pro	vid_subtitle	字幕内容	["字幕内容", "文本审核"]	识别视频字幕内容（复用文本审核规则）	0	t	t	2026-07-12 16:30:57.31123	\N	a5bf41f2-56bf-4fd6-9bdd-480d0ecd6a6c
41	video_audit_pro	vid_illegal	违法违规	["违法", "illegal"]	识别视频中的违法违规内容	0	t	t	2026-07-12 16:30:57.31123	\N	bcc03461-1f6a-43b5-b249-6660256ee2c6
42	image_audit_pro	ai_10	test	[]	\N	0	t	f	2026-07-12 20:24:00.223081	\N	6930fa50-cfa9-4372-9977-ce7905180c72
43	text_audit_pro	ai_13	测试	[]	\N	0	t	f	2026-07-12 21:01:28.111461	\N	6febad87-9a67-420e-8190-ca1b5709c8d0
\.


--
-- Data for Name: audit_point_libraries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_point_libraries (audit_point_id, library_id, sort_order, created_at) FROM stdin;
\.


--
-- Data for Name: audit_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_points (id, package_code, item_id, code, label, label_cn, description, medium_threshold, high_threshold, scope_text, risk_level, is_enabled, is_builtin, custom_wordset_id, custom_library_id, custom_reply_library_id, sort_order, created_at, updated_at, public_id) FROM stdin;
1	ad_compliance_detection_pro	1	pt_logotoSocialNetwork	pt_logotoSocialNetwork	画面中常见网络社交平台水印	\N	50	80	画面中常见网络社交平台水印	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	5103eef4-50db-49fb-a6d0-33021a050b5e
2	ad_compliance_detection_pro	1	pt_logotoSocialNetwork_lib	pt_logotoSocialNetwork_lib	自定义水印图库	\N	50	80	自定义图库用于命中返回该行标签	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	f6ee0c64-69cb-42fe-97bb-b775894d63be
3	ad_compliance_detection_pro	2	pt_qrCode	pt_qrCode	画面中疑似二维码	\N	50	80	画面中含二维码	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	99f25815-fc99-44fe-a99a-8aad8d4cc5a4
4	ad_compliance_detection_pro	2	pt_qrCode_lib	pt_qrCode_lib	自定义二维码图库	\N	50	80	自定义图库用于命中返回该行标签	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	15888f33-d08c-4b5f-a14f-b7a85a301e0f
5	ad_compliance_detection_pro	3	pt_toDirectContact_tii	pt_toDirectContact_tii	图中文字联系方式引流	\N	60	90	图中文字含网址/手机号/微信等联系方式	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	0185e1cb-3407-41f5-8767-adf1f671a9fd
6	ad_compliance_detection_pro	3	pt_toSocialNetwork_tii	pt_toSocialNetwork_tii	图中文字社交平台引流	\N	60	90	图中文字含社交平台引流信息	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	ac190593-48d3-43cd-b59e-da45d9806d2b
7	ad_compliance_detection_pro	3	pt_toShortVideos_tii	pt_toShortVideos_tii	图中文字短视频平台引流	\N	60	90	图中文字含短视频平台引流信息	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	431f02de-b137-46dd-bbeb-f7c84feb8854
8	ad_compliance_detection_pro	3	pt_investment_tii	pt_investment_tii	图中文字投资理财引流	\N	60	90	图中文字含投资理财引流	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	17154dd8-ab97-44df-9d59-25b6e794e2bf
9	ad_compliance_detection_pro	3	pt_recruitment_tii	pt_recruitment_tii	图中文字兼职招聘引流	\N	60	90	图中文字含兼职招聘引流	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	966ed54f-026e-4bd2-9fdb-801fae93b383
10	ad_compliance_detection_pro	3	pt_certificate_tii	pt_certificate_tii	图中文字办证套现引流	\N	60	90	图中文字含办证套现引流	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	ed2c6f62-dc89-4a61-9b3e-2ca123f0bb3d
11	ad_compliance_detection_pro	3	pt_toDirectContact_tii_lib	pt_toDirectContact_tii_lib	词库联系方式引流	\N	55	85	词库用于命中返回该行标签	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	67a890fc-ff99-45e2-ad41-99345b59edc2
12	ad_compliance_detection_pro	3	pt_toSocialNetwork_tii_lib	pt_toSocialNetwork_tii_lib	词库社交平台引流	\N	55	85	词库用于命中返回该行标签	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	d92a8790-2ce0-4610-9f27-61126be1fe61
13	image_audit_pro	4	politics_general	politics_general	涉政通用	\N	60	85	涉政通用：政治人物、政治事件、政治符号	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	624949cb-02cd-4637-b768-5f2af4f1b07c
14	image_audit_pro	5	porn_general	porn_general	涉黄通用	\N	55	85	涉黄通用：裸露、色情、低俗	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	43806759-5a8f-414d-b747-19107bc156c4
15	image_audit_pro	5	porn_general_tii	porn_general_tii	图中色情 OCR	\N	55	80	图中文字色情 OCR 识别	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	e61e5155-c83a-47a4-b4ae-22871a250075
16	image_audit_pro	5	porn_general_tii_lib	porn_general_tii_lib	词库色情关键词	\N	50	75	词库色情 OCR 关键词	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	97da537c-3bda-4dac-aafe-ad0ba389a1d2
17	image_audit_pro	5	porn_general_lib	porn_general_lib	自定义涉黄图库	\N	50	80	自定义涉黄图库	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	5369244a-33f0-4850-9527-bd1dddc0fadb
18	image_audit_pro	6	violence_general	violence_general	涉暴通用	\N	60	90	涉暴通用：血腥、暴力、武器	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	e9a24f4c-a2c4-4bef-8343-928a8f5c6eb7
19	image_audit_pro	6	violence_general_lib	violence_general_lib	自定义涉暴图库	\N	50	80	自定义涉暴图库	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	526b2730-7100-4572-92b5-8c14c0fae5b9
20	image_audit_pro	7	contraband_drug	contraband_drug	违禁药品（画面）	\N	50	80	画面疑似毒品、药品	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	52d5df29-6815-4ff0-bb37-3e99f09ae98f
78	audio_audit_pro	29	au_abuse_general	au_abuse_general	语音辱骂	\N	55	80	语音中辱骂内容	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	cb50b95e-f3c5-4252-88a3-cacb878ff42a
21	image_audit_pro	7	contraband_drug_tii	contraband_drug_tii	违禁药品（图中文字）	\N	50	80	图中文字疑似描述毒品、违禁品、禁限售等	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	a9608352-dabc-486e-9044-05b162395c32
22	image_audit_pro	7	contraband_drug_lib	contraband_drug_lib	违禁药品图库	\N	50	80	图库：选择图库用于命中返回 contraband_drug	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	e925f6ea-5ad8-4855-9799-9d888a60669e
23	image_audit_pro	7	contraband_drug_tii_lib	contraband_drug_tii_lib	违禁药品词库	\N	50	80	词库：选择词库用于命中返回 contraband_drug	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	583946a0-92c3-4c75-ab00-445136474835
24	image_audit_pro	7	contraband_gamble	contraband_gamble	违禁赌博（画面）	\N	50	80	画面疑似赌博物品	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	0031f638-a41a-42b3-b2ce-e4c6420191b9
25	image_audit_pro	7	contraband_gamble_tii	contraband_gamble_tii	违禁赌博（图中文字）	\N	50	80	图中文字疑似描述赌博行为	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	c6a26a6b-d13d-4f2d-b419-112df6344147
26	image_audit_pro	7	contraband_gamble_lib	contraband_gamble_lib	违禁赌博图库	\N	50	80	图库：选择图库用于命中返回 contraband_gamble	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	8338e9c7-9021-42e0-970b-13b61bc50a7e
27	image_audit_pro	7	contraband_gamble_tii_lib	contraband_gamble_tii_lib	违禁赌博词库	\N	50	80	词库：选择词库用于命中返回 contraband_gamble	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	b2082b28-954c-46f4-ae63-4b95f9091a8d
28	image_audit_pro	7	contraband_weapon	contraband_weapon	违禁器具（画面）	\N	50	80	画面疑似违禁器具、管制物品	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	2c55ece5-2f62-4a24-bec1-c94ce41e272e
29	image_audit_pro	7	contraband_weapon_tii	contraband_weapon_tii	违禁器具（图中文字）	\N	50	80	图中文字疑似描述违禁器具、管制物品	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	41fafb7e-cf7f-419d-adaf-b8c40adb3d3a
30	image_audit_pro	7	contraband_weapon_lib	contraband_weapon_lib	违禁器具图库	\N	50	80	图库：选择图库用于命中返回 contraband_weapon	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	d8676e61-e56b-4204-a091-c8ff23a86e36
31	image_audit_pro	7	contraband_weapon_tii_lib	contraband_weapon_tii_lib	违禁器具词库	\N	50	80	词库：选择词库用于命中返回 contraband_weapon	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	a288df3c-f090-4ea9-96f7-eaa3e54adce4
32	image_audit_pro	8	terrorism_general	terrorism_general	暴恐通用	\N	60	85	暴恐通用：极端组织符号、爆炸物、恐袭内容	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	5c9cabba-0c82-4b36-8968-ce13aadbe4a7
33	image_audit_pro	8	terrorism_general_lib	terrorism_general_lib	自定义暴恐图库	\N	55	85	自定义暴恐图库	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	d7af0240-b171-4b24-83e3-ce1164cdfb08
34	image_audit_pro	9	ad_general	ad_general	广告通用	\N	50	75	广告通用：画面含第三方广告或品牌	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	0d892b6e-dd2d-4eb8-a004-8d455665f25b
35	image_audit_pro	9	ad_general_lib	ad_general_lib	自定义广告图库	\N	50	75	自定义广告图库	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	b649823a-98e1-44cb-91c4-4af3a47d01f5
36	image_audit_pro	10	adlaw_general	adlaw_general	广告法通用	\N	55	80	广告法通用：极限用语、虚假承诺	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	c842b19b-8c17-41bd-9131-102c9131e7b0
37	image_audit_pro	10	adlaw_general_tii	adlaw_general_tii	图中广告法 OCR	\N	55	80	图中文字广告法违规 OCR	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	9e5adbb7-5e81-4078-beea-6904afc14563
38	image_audit_pro	10	adlaw_general_tii_lib	adlaw_general_tii_lib	词库广告法词	\N	50	75	词库广告法违规关键词	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	6ddd33d6-4c05-4fde-8229-2ae46977c8fa
39	image_audit_pro	10	adlaw_general_lib	adlaw_general_lib	自定义广告法图	\N	50	75	自定义广告法图库	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	f1d3d468-bd7f-4f4b-9f97-d34052d3a1f4
40	image_audit_pro	11	religion_general	religion_general	宗教通用	\N	50	75	宗教通用：宗教符号、宗教极端内容	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	2d00035f-62fa-4a35-b9db-2ec25aa4506c
41	image_audit_pro	11	religion_general_lib	religion_general_lib	自定义宗教图库	\N	45	70	自定义宗教图库	LOW	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	200b81db-1ce6-4ded-96be-f2004b9297ae
42	image_audit_pro	12	special_general	special_general	专项通用	\N	50	75	专项通用：专项检查任务标识的内容	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	8a2bd3fa-8422-44f4-bbc2-1de8151b5bf1
43	image_audit_pro	12	special_general_lib	special_general_lib	自定义专项图库	\N	45	70	自定义专项图库	LOW	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	46262cfc-0e42-4fc8-a874-ac6de24b0c62
44	text_audit_pro	13	tx_politics_current_president	tx_politics_current_president	现任国家主席	\N	60	85	涉及现任国家主席的影射和负面言论；提及现任国家主席的姓名、职务、亲昵称呼	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	c1541da7-7b2e-4948-b46f-6fcdf81e02b2
45	text_audit_pro	13	tx_politics_former_leaders	tx_politics_former_leaders	历任国家核心领导人	\N	60	85	对历任核心领导人（主席、总理）的影射和负面言论；提及历任核心领导人（主席、总理）的姓名、职务、亲昵称呼	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	8626a75b-4881-4d22-ba4c-fc228730381a
46	text_audit_pro	13	tx_politics_other_domestic_leaders	tx_politics_other_domestic_leaders	国内其他主要领导人	\N	60	85	对国内其他主要领导人（正国级、副国级）的负面言论；提及国内其他主要领导人的姓名、职务、亲昵称呼	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	e3e8d6d8-d974-4099-8d09-d34349dc823c
47	text_audit_pro	13	tx_politics_leaders_improper	tx_politics_leaders_improper	核心领导人不当表述	\N	60	85	不合时宜、不合身份、不合场所地谈论现历任核心领导人	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	304f2bbc-a96a-4321-95c6-27cabfd53aa9
48	text_audit_pro	13	tx_politics_foreign_leaders	tx_politics_foreign_leaders	现历任国外领导人	\N	60	85	提及现任/历任国外领导人	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	3237cb77-2963-4f64-b152-b5f138fe3944
49	text_audit_pro	13	tx_politics_main_forbidden_events	tx_politics_main_forbidden_events	主要政治禁宣事件	\N	60	85	涉及国内禁止提及的主要政治禁宣事件	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	a16d26c2-3337-45e0-b183-a665325633e5
50	text_audit_pro	13	tx_politics_other_forbidden_events	tx_politics_other_forbidden_events	其他政治禁宣事件	\N	60	85	涉及国内禁止提及的其他政治禁宣事件	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	91dc0004-f373-47e9-9f1e-b0e88ffc4ea5
85	document_audit_pro	36	doc_sensitive	doc_sensitive	文档敏感信息	\N	60	85	文档中敏感信息检测	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	296ef19c-8479-4463-b385-d455c91bc8a8
51	text_audit_pro	13	tx_politics_modern_political	tx_politics_modern_political	近现代政治事件或国际关系	\N	60	85	对近现代中国政治事件、世界形势、国际关系的负面讨论；提及（中国）近现代政治军事事件的名称、组织、人物	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	66dbfa29-41b5-4055-820b-2240deb19c30
52	text_audit_pro	13	tx_politics_territorial_secession	tx_politics_territorial_secession	中国领土分裂	\N	60	85	宣扬分裂主义言论、支持分裂主义组织、或参与分裂主义活动等论述	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	326af97d-e689-425c-9b36-c6c356019c76
53	text_audit_pro	13	tx_politics_ideology_violation	tx_politics_ideology_violation	违规的意识形态	\N	60	85	否定党、国家、政府、制度的观点和思想倾向，对政治政体象征的负面言论和不当表述	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	89ac54c7-aa64-4ab2-92e6-8b71a872b1c9
54	text_audit_pro	13	tx_politics_political_entity	tx_politics_political_entity	政治实体	\N	60	85	提及党组织相关的理论、活动；提及政协会议、国家政策；提及军事装备、活动、组织；提及国家机构、政府机关、公职职务名称	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	753e8d66-391f-47c9-ad8c-48d8881e2903
55	text_audit_pro	14	tx_terrorism	tx_terrorism	暴恐	\N	60	85	暴恐违规内容	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	ba9950b1-e4a4-4caa-853e-c5584c651806
56	text_audit_pro	15	tx_porn	tx_porn	色情	\N	60	85	色情违规内容	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	288fe7bd-368b-4b2f-87d7-19789c50e126
57	text_audit_pro	16	tx_advertising	tx_advertising	广告法	\N	55	80	广告法违规内容	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	2b47cf9f-b2a4-4bd9-a8d5-be0587617aa8
58	text_audit_pro	17	tx_abuse	tx_abuse	辱骂	\N	55	80	辱骂或人身攻击	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	cf15f01e-0953-4f4c-8e59-05ae06dfabeb
59	text_audit_pro	18	tx_vulgar	tx_vulgar	低俗	\N	55	80	低俗内容	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	ffcfbb20-af44-41ef-a3d0-27ed6b1c24a6
60	text_audit_pro	19	tx_minor_protection	tx_minor_protection	未成年保护	\N	55	80	未成年人保护违规	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	6cd7a1dd-7be4-4572-9ad3-93a37481c984
61	text_audit_pro	20	tx_values	tx_values	价值观	\N	55	80	价值观违规	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	bde273f4-fad5-4c02-bdfc-b12f1d9b3a0d
62	text_audit_pro	21	tx_illegal	tx_illegal	违法违规	\N	60	85	违法违规	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	656a6e1a-eae8-43ee-916a-3ca37a43a1e7
63	text_audit_pro	22	tx_privacy_pii	tx_privacy_pii	PII 检测	\N	60	85	PII 检测：身份证/手机/银行卡	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	09d4aa25-339c-4ef8-87a3-a2ea00a3e743
64	text_audit_pro	22	tx_privacy_contact	tx_privacy_contact	联系方式检测	\N	55	80	联系方式检测：地址/邮箱/微信	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	af18d5cc-5b7c-49b5-aa78-feaae35b8bf5
65	text_audit_pro	23	tx_promptattack_basic	tx_promptattack_basic	基础越狱指令	\N	70	90	基础越狱指令识别	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	b913553d-ac13-4bd3-9a58-665b103b2f4a
66	text_audit_pro	23	tx_promptattack_adv	tx_promptattack_adv	高级越狱指令	\N	65	85	高级越狱指令识别	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	9fbac54d-4fbb-4f1b-a5fc-ac4efe6c3389
67	text_audit_pro	24	bad_minor	bad_minor	未成年不适	\N	60	85	识别画面/文本中未成年人涉烟酒、纹身、恋爱、裸露、暴力等不当场景	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	003ef517-ee28-43d1-bb73-106a37e7c6a1
68	text_audit_pro	24	bad_bias	bad_bias	偏见歧视	\N	60	85	识别种族/民族/地域/性别/职业/宗教/性取向等歧视性内容	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	459a73e6-1151-4a62-ad3a-e88c86d68019
69	text_audit_pro	24	bad_values	bad_values	不良价值观	\N	60	85	识别拜金/炫富/躺平摆烂/啃老/畸形审美/崇洋媚外等扭曲价值观	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	6537a8e4-6071-4fde-919a-85fa6e6ae7f6
70	text_audit_pro	24	bad_abuse	bad_abuse	攻击辱骂	\N	60	85	识别画面/文本中人身攻击/P图丑化/恶意诅咒/阴阳怪气/PUA话术	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	0006f8d1-bf9b-4384-a8a4-fb3f07c55aba
71	text_audit_pro	24	bad_vulgar	bad_vulgar	低俗口头语	\N	60	85	识别粗口/脏话/谐音脏话/缩写脏话/网络黑话脏话	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	ac92907c-9ac4-4d11-b3ea-36136dad96f6
72	text_audit_pro	24	bad_superstition	bad_superstition	封建迷信	\N	60	85	识别算命/占卜/看相/测字/跳大神/巫术/伪科学养生/转运改命/邪教组织	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	89e2e25f-ed98-41df-b38f-bdc660838a1a
73	text_audit_pro	24	bad_spam	bad_spam	无意义灌水	\N	55	80	识别大量重复字符/无意义符号堆叠/纯水贴/凑字数/低质水文	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	aa8ce4dc-268f-4c7f-abe7-46853352fa2e
74	audio_audit_pro	25	au_politics_general	au_politics_general	语音涉政	\N	60	85	语音中涉政表述	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	ca7a2983-55a3-4e04-8076-3a2af8a30dd0
75	audio_audit_pro	26	au_porn_general	au_porn_general	语音色情	\N	60	85	语音中含色情表述	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	a3bd89f1-02ca-4c4e-88de-796712c5ed02
76	audio_audit_pro	27	au_violence_general	au_violence_general	语音暴恐	\N	60	85	语音中含暴恐表述	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	3f642fbf-fb6d-46c2-89b6-c51ceca32ef1
77	audio_audit_pro	28	au_adlaw_general	au_adlaw_general	语音广告法	\N	55	80	语音中广告法违规词	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	80c8b8a0-7b37-4863-93f1-d3aec65dbb5d
79	audio_audit_pro	30	au_minor_general	au_minor_general	语音未成年保护	\N	55	80	语音中未成年保护违规	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	dca4feef-103e-4873-92d5-eb2965532403
80	audio_audit_pro	31	au_illegal_general	au_illegal_general	语音违法违规	\N	60	85	语音中违法违规表述	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	f62b5290-7041-4705-b68a-3efa650b6278
81	audio_audit_pro	32	au_voiceprint_moaning	au_voiceprint_moaning	娇喘检测	\N	60	85	识别语音中的娇喘等异常发声模式	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	07b538c7-908b-438b-ab3c-a700af076aae
82	audio_audit_pro	33	au_audiopquality_no_speech	au_audiopquality_no_speech	无语音内容	\N	50	75	识别音频中无有效语音内容	LOW	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	8cb34b7d-3cff-4ff2-8446-4ef116d2891a
83	document_audit_pro	34	doc_image_general	doc_image_general	文档图片审核	\N	55	80	文档中嵌入图片内容审核	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	8c4c9da4-160c-4275-a487-f34c4f99abeb
84	document_audit_pro	35	doc_text_general	doc_text_general	文档文本审核	\N	55	80	文档中文本内容审核	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	a129d537-5768-41d5-99bf-e9fe2caa47e9
86	document_audit_pro	37	doc_illegal	doc_illegal	文档违法违规	\N	60	85	文档中违法违规内容	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	f303bbf2-2432-4732-b1ec-e25f5efb8ef0
87	video_audit_pro	38	vid_frame_general	vid_frame_general	视频画面审核	\N	55	80	视频画面内容审核	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	ad535aaa-f862-4509-b1c9-80ce4c1d456e
88	video_audit_pro	39	vid_audio_general	vid_audio_general	视频音轨审核	\N	55	80	视频音轨内容审核	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	170c991c-10dc-4056-b369-3c4bf2085071
89	video_audit_pro	40	vid_subtitle	vid_subtitle	视频字幕审核	\N	55	80	视频字幕内容审核	MEDIUM	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	d33f9dc7-e620-4469-8f09-9a35f0d7251a
90	video_audit_pro	41	vid_illegal	vid_illegal	视频违法违规	\N	60	85	视频违法违规内容	HIGH	t	t	\N	\N	\N	0	2026-07-12 16:30:57.31123	\N	6d21d9e8-7156-4354-ab64-8033445e57d6
92	image_audit_pro	42	ap_42_1	ap_42_1	一号领导 ｜ 图中出现	\N	60	90	\N	MEDIUM	t	f	\N	\N	\N	0	2026-07-12 21:50:22.14376	\N	eb1c0581-0428-43bc-b6e6-36d5a132e1f6
\.


--
-- Data for Name: detection_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.detection_rules (id, service_code, label, label_cn, description, medium_threshold, high_threshold, scope_text, is_enabled, custom_wordset_id, audit_point_id, created_at, updated_at, public_id) FROM stdin;
1	ad_compliance_detection_pro	pt_logotoSocialNetwork	常见网络社交平台水印	画面中疑似含有常见网络社交平台水印	50	80	常见网络社交平台水印	t	\N	\N	2026-07-12 16:30:57.31123	\N	5d3795a8-af02-41c3-b2c8-ee80a72f43e6
2	ad_compliance_detection_pro	pt_qrCode	二维码	画面中疑似含有二维码	50	80	画面中含有二维码	t	\N	\N	2026-07-12 16:30:57.31123	\N	d98427f2-f601-47aa-82cf-33355b277939
3	ad_compliance_detection_pro	pt_programCode	小程序码	画面中疑似含有小程序码	50	80	画面中含有小程序码	f	\N	\N	2026-07-12 16:30:57.31123	\N	e8a82c6f-c45b-48f5-9d7e-ecb0abfd174d
4	ad_compliance_detection_pro	pt_toDirectContact_tii	联系方式引流	图中文字含联系方式类引流信息	60	90	图中文字含网址、手机号、微信QQ等联系方式类引流信息	f	\N	\N	2026-07-12 16:30:57.31123	\N	3503931b-b010-4722-837a-e002d58f834e
5	ad_compliance_detection_pro	pt_toSocialNetwork_tii	社交平台引流	图中文字含有社交平台引流信息	60	90	图中文字含有常见社交平台引流信息	t	\N	\N	2026-07-12 16:30:57.31123	\N	da55a503-465e-400e-9dc4-d4440218f2e2
6	ad_compliance_detection_pro	pt_toShortVideos_tii	短视频平台引流	图中文字含短视频平台引流信息	60	90	图中文字含常见短视频平台引流信息	f	\N	\N	2026-07-12 16:30:57.31123	\N	295ee2e1-b373-4640-bd8c-d933a5e80417
7	ad_compliance_detection_pro	pt_investment_tii	投资理财引流	图中文字含投资理财类广告引流	60	90	图中文字含投资理财类广告引流	f	\N	\N	2026-07-12 16:30:57.31123	\N	2b6f34bd-a320-4341-8f07-70bbb125fbab
8	ad_compliance_detection_pro	pt_recruitment_tii	兼职招聘引流	图中文字含兼职招聘类广告引流	60	90	图中文字含兼职招聘类广告引流	f	\N	\N	2026-07-12 16:30:57.31123	\N	5104cf57-e702-42d4-8608-0908cb8d0423
9	ad_compliance_detection_pro	pt_certificate_tii	办证套现引流	图中文字含办证套现类广告引流	60	90	图中文字含办证套现类广告引流	f	\N	\N	2026-07-12 16:30:57.31123	\N	f610db0a-62fd-44a7-b0ae-54c0b64b2484
10	text_audit_pro	tx_politics	涉政	文本中含涉政表述	60	85	涉政违规内容	t	\N	\N	2026-07-12 16:30:57.31123	\N	a40f5913-6443-4cec-9abf-adc4a091fe45
11	text_audit_pro	tx_terrorism	暴恐	文本中含暴恐表述	60	85	暴恐违规内容	t	\N	\N	2026-07-12 16:30:57.31123	\N	5c14a1f3-968e-4d2e-8500-8acf02dd4af0
12	text_audit_pro	tx_porn	色情	文本中含色情表述	60	85	色情违规内容	t	\N	\N	2026-07-12 16:30:57.31123	\N	046f81a3-d4a2-40fd-92a5-e483ff1b07a7
13	text_audit_pro	tx_advertising	广告法违规	文本中含广告法违规表述	55	80	广告法违规内容（极限用词、承诺保证等）	t	\N	\N	2026-07-12 16:30:57.31123	\N	0b64bb1b-6e85-464f-b591-f8f6f21fa9df
14	text_audit_pro	tx_abuse	辱骂	文本中含辱骂或人身攻击	55	80	辱骂或人身攻击内容	f	\N	\N	2026-07-12 16:30:57.31123	\N	2c2aa6a8-f11e-4b50-aa00-25bef570914e
15	text_audit_pro	tx_vulgar	低俗	文本中含低俗表述	55	80	低俗内容	f	\N	\N	2026-07-12 16:30:57.31123	\N	3fbe144b-0463-43ac-a97c-61f6a6e3cecd
16	text_audit_pro	tx_minor_protection	未成年保护	文本中含未成年保护相关违规	55	80	未成年人保护违规内容	f	\N	\N	2026-07-12 16:30:57.31123	\N	e85c881f-7bd9-46fe-8167-a5af370c5dcb
17	text_audit_pro	tx_values	价值观	文本中含价值观违规表述	55	80	价值观违规内容	f	\N	\N	2026-07-12 16:30:57.31123	\N	cc577746-e582-41ee-b483-76e0fbc234af
18	text_audit_pro	tx_illegal	违法违规	文本中含违法违规表述	60	85	违法违规内容	f	\N	\N	2026-07-12 16:30:57.31123	\N	7728a49c-dac1-4b92-8802-ef08444b70fd
\.


--
-- Data for Name: disposition_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.disposition_rules (id, public_id, code, name, description, is_enabled, risk_levels, sensitive_levels, review_rule_id, sample_ratio, auto_action_overrides, is_builtin, is_editable, locked_by_id, locked_at, created_by_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: human_review_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.human_review_configs (id, service_code, is_enabled, risk_levels, review_rule_id, created_at, updated_at, public_id) FROM stdin;
1	ad_compliance_detection_pro	f		\N	2026-07-12 16:30:57.31123	\N	651c9bcb-de50-4a23-8c3c-4367eaf68ee2
2	text_audit_pro	f		\N	2026-07-12 16:30:57.31123	\N	b132febe-cc0d-4223-babe-caf24a6a381a
\.


--
-- Data for Name: image_set_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.image_set_items (id, set_id, storage_key, original_filename, mime_type, file_size, sha256, created_at, public_id) FROM stdin;
\.


--
-- Data for Name: image_sets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.image_sets (id, code, name, "group", action, kind, description, is_active, ignored_services, item_count, capacity, created_at, updated_at, public_id) FROM stdin;
\.


--
-- Data for Name: libraries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.libraries (id, code, name, library_type, kind, description, is_active, is_platform, is_deleted, deleted_at, ignored_services, effective_from, effective_until, created_at, updated_at, public_id) FROM stdin;
1	lib_w_bad_minor	不良词库-未成年不适	word	黑名单	未成年人涉烟酒、纹身、恋爱、裸露、暴力等不当场景关键词	t	t	f	\N	[]	\N	\N	2026-07-12 16:30:57.31123	\N	9917df2e-e5a4-4ccd-86c7-f731121a5600
2	lib_w_bad_bias	不良词库-偏见歧视	word	黑名单	种族/民族/地域/性别/职业/宗教/性取向等歧视性关键词	t	t	f	\N	[]	\N	\N	2026-07-12 16:30:57.31123	\N	a44213f1-1d27-4b24-9b4e-7be1c512e4c4
3	lib_w_bad_values	不良词库-不良价值观	word	黑名单	拜金/炫富/躺平摆烂/啃老/畸形审美/崇洋媚外等扭曲价值观关键词	t	t	f	\N	[]	\N	\N	2026-07-12 16:30:57.31123	\N	6253c3eb-38f6-455e-984c-3e89cf892699
4	lib_w_bad_abuse	不良词库-攻击辱骂	word	黑名单	人身攻击/恶意诅咒/阴阳怪气/PUA话术关键词	t	t	f	\N	[]	\N	\N	2026-07-12 16:30:57.31123	\N	8bd70169-4b38-4274-a90a-61a0cd9c3b8f
5	lib_w_bad_vulgar	不良词库-低俗口头语	word	黑名单	粗口/脏话/谐音脏话/缩写脏话/网络黑话脏话	t	t	f	\N	[]	\N	\N	2026-07-12 16:30:57.31123	\N	5e9d2057-2773-4475-bb97-26abcce3e1c7
6	lib_w_bad_superstition	不良词库-封建迷信	word	黑名单	算命/占卜/看相/测字/跳大神/巫术/伪科学养生/转运改命/邪教组织关键词	t	t	f	\N	[]	\N	\N	2026-07-12 16:30:57.31123	\N	19da9c03-4f3f-46c8-9feb-9d9cbf7be74f
7	lib_w_bad_spam	不良词库-无意义灌水	word	黑名单	大量重复字符/无意义符号堆叠/纯水贴/凑字数/低质水文关键词	t	t	f	\N	[]	\N	\N	2026-07-12 16:30:57.31123	\N	925e8ae4-7673-4e60-8496-056cd4234057
8	lib_w_politics_current_president	涉政词库-现任国家主席	word	黑名单	现任国家主席的姓名、职务、亲昵称呼及影射/负面言论关键词	t	t	f	\N	[]	\N	\N	2026-07-12 16:30:57.31123	\N	9e866c50-6529-4256-b1d8-b0ccf0bb4219
9	lib_w_politics_former_leaders	涉政词库-历任国家核心领导人	word	黑名单	历任核心领导人（主席、总理）的姓名、职务、亲昵称呼及影射/负面言论关键词	t	t	f	\N	[]	\N	\N	2026-07-12 16:30:57.31123	\N	21e9cbc0-1503-402e-8bc1-cbfb7e162cdb
10	lib_w_politics_other_domestic_leaders	涉政词库-国内其他主要领导人	word	黑名单	正国级/副国级国内其他主要领导人姓名、职务、亲昵称呼及负面言论关键词	t	t	f	\N	[]	\N	\N	2026-07-12 16:30:57.31123	\N	0e616674-c87f-452f-bb31-99ffb6c358a5
11	lib_w_politics_leaders_improper	涉政词库-核心领导人不当表述	word	黑名单	不合时宜/不合身份/不合场所谈论现历任核心领导人的不当表述关键词	t	t	f	\N	[]	\N	\N	2026-07-12 16:30:57.31123	\N	b3d4ec16-6318-4a56-b71d-a58545e1c541
12	lib_w_politics_foreign_leaders	涉政词库-现历任国外领导人	word	黑名单	现任/历任国外领导人姓名及关联关键词	t	t	f	\N	[]	\N	\N	2026-07-12 16:30:57.31123	\N	b9c1544c-7a57-49f3-8f8e-126258ccb3df
13	lib_w_politics_main_forbidden_events	涉政词库-主要政治禁宣事件	word	黑名单	国内禁止提及的主要政治禁宣事件相关关键词	t	t	f	\N	[]	\N	\N	2026-07-12 16:30:57.31123	\N	b58b25d8-4ccc-48bd-b970-51f90bea6a91
14	lib_w_politics_other_forbidden_events	涉政词库-其他政治禁宣事件	word	黑名单	国内禁止提及的其他政治禁宣事件相关关键词	t	t	f	\N	[]	\N	\N	2026-07-12 16:30:57.31123	\N	2283c270-f0e1-4713-94d3-e275add8bb79
15	lib_w_politics_modern_political	涉政词库-近现代政治事件或国际关系	word	黑名单	近现代中国政治事件、世界形势、国际关系相关负面表述及政治军事事件/组织/人物关键词	t	t	f	\N	[]	\N	\N	2026-07-12 16:30:57.31123	\N	5a3f9193-3049-4aa8-87a1-27a4e76ad5aa
16	lib_w_politics_territorial_secession	涉政词库-中国领土分裂	word	黑名单	分裂主义言论、支持分裂主义组织、参与分裂主义活动相关关键词	t	t	f	\N	[]	\N	\N	2026-07-12 16:30:57.31123	\N	d1ff5835-8112-4f96-b3eb-884816674b57
17	lib_w_politics_ideology_violation	涉政词库-违规的意识形态	word	黑名单	否定党/国家/政府/制度的观点、政治政体象征负面言论及不当表述关键词	t	t	f	\N	[]	\N	\N	2026-07-12 16:30:57.31123	\N	2f902328-68c1-413e-80ec-fe794d43a885
18	lib_w_politics_political_entity	涉政词库-政治实体	word	黑名单	党组织理论/活动、政协会议、国家政策、军事装备/活动/组织、国家机构/政府机关/公职职务名称关键词	t	t	f	\N	[]	\N	\N	2026-07-12 16:30:57.31123	\N	b3006f7a-f27b-4aaa-9818-4463a9f5ea68
19	lib_w_1	测试	word	黑名单	\N	t	f	f	\N	[]	\N	\N	2026-07-12 17:57:36.322178	\N	2d3c2dbe-3f75-45bd-98ca-2978594a5040
20	lib_w_2	test	word	白名单	\N	t	f	f	\N	[]	\N	\N	2026-07-12 19:24:59.433023	\N	c042b50e-a15c-47bc-80b2-2792a4b43b65
\.


--
-- Data for Name: library_item_references; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.library_item_references (item_id, library_id, created_at) FROM stdin;
\.


--
-- Data for Name: library_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.library_items (id, library_id, word, trigger, reply, storage_key, sha256, original_filename, mime_type, file_size, is_deleted, deleted_at, created_at, public_id) FROM stdin;
1	19	测试	\N	\N	\N	\N	\N	\N	\N	f	\N	2026-07-12 17:57:36.322178	b8f43008-647a-4791-88ef-592e63c89993
2	20	11	\N	\N	\N	\N	\N	\N	\N	f	\N	2026-07-12 19:24:59.433023	d943e2d3-ad46-421e-a9de-23e9de5d40d9
\.


--
-- Data for Name: llm_calls; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.llm_calls (id, public_id, task_id, version_id, correlation_id, model, ok, schema_valid, truncated, input_chars, token_in, token_out, latency_ms, error, created_at) FROM stdin;
1	019f582c-c2fb-71c7-a795-0a1fe55e8272	1	1	8545d7e6e42343ab91201553df70327c	claude-opus-4-7	t	t	f	3	819	65	2506	\N	2026-07-13 05:12:33.791082+08
2	019f582d-41cc-75a6-a01a-6140b97205f4	1	1	f36b8e93c40744559afdeaaea96293c7	claude-opus-4-7	t	t	f	32	846	633	7644	\N	2026-07-13 05:13:01.128529+08
3	019f590e-1c29-763d-9a88-4a7d443ed4b4	7	5	5d62d560e60344f9a4b38ab3e3b191aa	claude-opus-4-7	t	t	f	4	19401	82	3881	\N	2026-07-13 09:18:40.8549+08
\.


--
-- Data for Name: material_package_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.material_package_items (id, package_id, material_id, "position", review_task_id, public_id) FROM stdin;
\.


--
-- Data for Name: material_packages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.material_packages (id, name, description, material_type, status, creator_id, created_at, updated_at, public_id) FROM stdin;
\.


--
-- Data for Name: material_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.material_versions (id, material_id, version_no, storage_key, original_filename, mime_type, file_size, checksum, text_body, extra, created_by_id, created_at, public_id) FROM stdin;
2	2	1	materials/2/v1/20260712.txt	text.txt	text/plain	9	2787ed8925dcd7661c80f398d2a1f8fa6aa4a75d14d67fcc45ddba62e74c17ca	故人归	{}	1	2026-07-12 17:04:08.358327+08	244363c7-39b1-4016-a5a9-e0692e5deef0
3	3	1	materials/3/v1/20260712.txt	text.txt	text/plain	9	290e52a790f28238686d77efa88db7653bf0caaa976875a302c9095e0475bc2a	他天天	{}	5	2026-07-12 23:25:14.355109+08	c87e1a64-cd12-4242-9524-2a7eb60c8725
4	4	1	materials/4/v1/20260712.txt	text.txt	text/plain	9	3c8a663eb9216c6cd1f5c323c166c99b0925b2a8ada4e59bb16d251181013055	啦啦啦	{}	5	2026-07-13 02:13:18.271243+08	2ec7d2ec-5307-4cde-935b-917acffecc4f
5	5	1	materials/5/v1/20260712.txt	text.txt	text/plain	4	9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08	test	{}	5	2026-07-13 02:50:00.474899+08	55b0a7ce-83b1-4d43-bf1b-c92ae289b4ad
1	1	1	materials/1/v1/20260712.txt	text.txt	text/plain	9	67b15dee2c458dac4a22f33e73c7db151d5b38a09d34f6a1d72215104984795c	本产品是最有效的保健品，3天根治失眠，无任何副作用，全网最低价！	{}	1	2026-07-12 16:56:14.588454+08	a6e6c92c-d313-4e17-8055-a1c09dfbefbe
\.


--
-- Data for Name: materials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.materials (id, title, description, material_type, status, tags, metadata, submitter_id, current_version_id, created_at, updated_at, public_id) FROM stdin;
2	未命名文案	\N	TEXT	IN_REVIEW	{"source": "create_task_page"}	{}	1	2	2026-07-12 17:04:08.326529+08	2026-07-12 17:04:08.380276+08	0a16e5fc-0461-4f71-9884-ddcc56a721ea
3	未命名文案	\N	TEXT	IN_REVIEW	{"source": "create_task_page", "strategy_id": 1}	{}	5	3	2026-07-12 23:25:14.303873+08	2026-07-12 23:25:14.383935+08	c2c7e198-b358-44d1-9088-1a8d6d1d459c
4	未命名文案	\N	TEXT	IN_REVIEW	{"source": "create_task_page", "strategy_id": 2}	{}	5	4	2026-07-13 02:13:18.241137+08	2026-07-13 02:13:18.292781+08	51fe55e3-cf30-41a6-ba63-aea85efb4c97
5	未命名文案	\N	TEXT	IN_REVIEW	{"source": "create_task_page", "strategy_id": 2}	{}	5	5	2026-07-13 02:50:00.445572+08	2026-07-13 02:50:00.496667+08	b9a506a0-907e-4387-abbe-ff2e2bd2d32b
1	未命名文案	\N	TEXT	APPROVED	{"source": "create_task_page"}	{}	1	1	2026-07-12 16:56:14.536255+08	2026-07-13 05:12:36.36036+08	6d1501f7-75ab-42ad-9176-ebe6fe0bacbd
\.


--
-- Data for Name: ops_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ops_log (id, actor, action, status, argv, cwd, detail, message, created_at, public_id) FROM stdin;
1	manual:root	scripts.init_db.run	started	/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py --i-know	/Users/kelly/Documents/test/adreview-platform/backend	{"argv": ["/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py", "--i-know"], "env_AGREE_RESET": "YES", "env_I_UNDERSTAND_DATA_LOSS": "I_UNDERSTAND_DATA_LOSS", "env_RESEED_ALLOWED": "YES", "allow_flag": true, "warning": "DROP SCHEMA public CASCADE \\u2014 full data loss"}	init_db.py starting destructive reset	2026-07-12 17:33:11.464408+08	52d7f301-d705-4112-99f1-31b2ac9a9b6f
2	manual:root	scripts.init_db.run	started	/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py --i-know	/Users/kelly/Documents/test/adreview-platform/backend	{"argv": ["/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py", "--i-know"], "env_AGREE_RESET": "YES", "env_I_UNDERSTAND_DATA_LOSS": "I_UNDERSTAND_DATA_LOSS", "env_RESEED_ALLOWED": "YES", "allow_flag": true, "warning": "DROP SCHEMA public CASCADE \\u2014 full data loss"}	init_db.py starting destructive reset	2026-07-12 17:33:36.54368+08	a236303d-db14-477a-9c08-42b221cb9c2f
3	manual:root	scripts.seed.run	refused	scripts/seed.py	/Users/kelly/Documents/test/adreview-platform/backend	{"argv": ["scripts/seed.py"], "env_RESEED_ALLOWED": null, "env_SEED_CONFIRM_DELETE": null, "args_purge_removed": false, "args_purge_user_data": false, "args_dry_run": false, "args_allow_reseed": false, "reason": "non-empty DB without RESEED_ALLOWED+--allow-reseed"}	seed.py refused: live-data guard tripped	2026-07-12 17:34:09.427814+08	2a527e0b-5cee-4b1f-87b3-0dc6243559e2
4	manual:root	scripts.init_db.run	started	/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py --i-know	/Users/kelly/Documents/test/adreview-platform/backend	{"argv": ["/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py", "--i-know"], "env_AGREE_RESET": "YES", "env_I_UNDERSTAND_DATA_LOSS": "I_UNDERSTAND_DATA_LOSS", "env_RESEED_ALLOWED": "YES", "allow_flag": true, "warning": "DROP SCHEMA public CASCADE \\u2014 full data loss"}	init_db.py starting destructive reset	2026-07-12 19:40:54.649643+08	728d0a33-5d7a-4378-9e1c-58f00e7f4ea2
5	manual:root	scripts.init_db.run	started	/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py --i-know	/Users/kelly/Documents/test/adreview-platform/backend	{"argv": ["/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py", "--i-know"], "env_AGREE_RESET": "YES", "env_I_UNDERSTAND_DATA_LOSS": "I_UNDERSTAND_DATA_LOSS", "env_RESEED_ALLOWED": "YES", "allow_flag": true, "warning": "DROP SCHEMA public CASCADE \\u2014 full data loss"}	init_db.py starting destructive reset	2026-07-12 20:04:13.833774+08	c8eafa43-2d48-40c0-b2f7-319f17134a28
6	manual:root	scripts.init_db.run	started	/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py --i-know	/Users/kelly/Documents/test/adreview-platform/backend	{"argv": ["/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py", "--i-know"], "env_AGREE_RESET": "YES", "env_I_UNDERSTAND_DATA_LOSS": "I_UNDERSTAND_DATA_LOSS", "env_RESEED_ALLOWED": "YES", "allow_flag": true, "warning": "DROP SCHEMA public CASCADE \\u2014 full data loss"}	init_db.py starting destructive reset	2026-07-12 21:09:04.736445+08	b684d340-7c63-4b41-83b8-055bb7a7d887
7	manual:root	scripts.init_db.run	started	/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py --i-know	/Users/kelly/Documents/test/adreview-platform/backend	{"argv": ["/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py", "--i-know"], "env_AGREE_RESET": "YES", "env_I_UNDERSTAND_DATA_LOSS": "I_UNDERSTAND_DATA_LOSS", "env_RESEED_ALLOWED": "YES", "allow_flag": true, "warning": "DROP SCHEMA public CASCADE \\u2014 full data loss"}	init_db.py starting destructive reset	2026-07-12 21:21:22.447358+08	e2e1a81b-0651-4a1f-a750-71c02aeed192
8	manual:root	scripts.init_db.run	started	/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py --i-know	/Users/kelly/Documents/test/adreview-platform/backend	{"argv": ["/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py", "--i-know"], "env_AGREE_RESET": "YES", "env_I_UNDERSTAND_DATA_LOSS": "I_UNDERSTAND_DATA_LOSS", "env_RESEED_ALLOWED": "YES", "allow_flag": true, "warning": "DROP SCHEMA public CASCADE \\u2014 full data loss"}	init_db.py starting destructive reset	2026-07-12 21:44:44.102645+08	6bd9d82b-8c78-441a-b6cb-3d04a7b8f85f
9	manual:root	scripts.init_db.run	started	/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py --i-know	/Users/kelly/Documents/test/adreview-platform/backend	{"argv": ["/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py", "--i-know"], "env_AGREE_RESET": "YES", "env_I_UNDERSTAND_DATA_LOSS": "I_UNDERSTAND_DATA_LOSS", "env_RESEED_ALLOWED": "YES", "allow_flag": true, "warning": "DROP SCHEMA public CASCADE \\u2014 full data loss"}	init_db.py starting destructive reset	2026-07-12 21:55:38.818708+08	c3151ef1-a182-4d44-9f35-4ea5b1f6a90e
10	manual:root	scripts.init_db.run	started	/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py --i-know	/Users/kelly/Documents/test/adreview-platform/backend	{"argv": ["/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py", "--i-know"], "env_AGREE_RESET": "YES", "env_I_UNDERSTAND_DATA_LOSS": "I_UNDERSTAND_DATA_LOSS", "env_RESEED_ALLOWED": "YES", "allow_flag": true, "warning": "DROP SCHEMA public CASCADE \\u2014 full data loss"}	init_db.py starting destructive reset	2026-07-12 22:01:35.04662+08	ca697a83-3fcd-42e1-b5f3-06624b30d98e
11	manual:root	scripts.init_db.run	started	/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py --i-know	/Users/kelly/Documents/test/adreview-platform/backend	{"argv": ["/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py", "--i-know"], "env_AGREE_RESET": "YES", "env_I_UNDERSTAND_DATA_LOSS": "I_UNDERSTAND_DATA_LOSS", "env_RESEED_ALLOWED": "YES", "allow_flag": true, "warning": "DROP SCHEMA public CASCADE \\u2014 full data loss"}	init_db.py starting destructive reset	2026-07-13 05:15:05.561481+08	019f582f-09d9-722a-ae62-179d509e6166
12	manual:root	scripts.init_db.run	started	/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py --i-know	/Users/kelly/Documents/test/adreview-platform/backend	{"argv": ["/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py", "--i-know"], "env_AGREE_RESET": "YES", "env_I_UNDERSTAND_DATA_LOSS": "I_UNDERSTAND_DATA_LOSS", "env_RESEED_ALLOWED": "YES", "allow_flag": true, "warning": "DROP SCHEMA public CASCADE \\u2014 full data loss"}	init_db.py starting destructive reset	2026-07-13 05:18:07.979473+08	019f5831-d26b-7490-bcf9-9c8e1b145697
13	manual:root	scripts.init_db.run	started	/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py --i-know	/Users/kelly/Documents/test/adreview-platform/backend	{"argv": ["/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py", "--i-know"], "env_AGREE_RESET": "YES", "env_I_UNDERSTAND_DATA_LOSS": "I_UNDERSTAND_DATA_LOSS", "env_RESEED_ALLOWED": "YES", "allow_flag": true, "warning": "DROP SCHEMA public CASCADE \\u2014 full data loss"}	init_db.py starting destructive reset	2026-07-13 09:16:27.313275+08	019f590c-0331-72a3-9282-d5cb39f80bdc
14	manual:root	scripts.init_db.run	started	/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py --i-know	/Users/kelly/Documents/test/adreview-platform/backend	{"argv": ["/Users/kelly/Documents/test/adreview-platform/backend/scripts/init_db.py", "--i-know"], "env_AGREE_RESET": "YES", "env_I_UNDERSTAND_DATA_LOSS": "I_UNDERSTAND_DATA_LOSS", "env_RESEED_ALLOWED": "YES", "allow_flag": true, "warning": "DROP SCHEMA public CASCADE \\u2014 full data loss"}	init_db.py starting destructive reset	2026-07-13 09:23:17.763247+08	019f5912-4683-74f2-a97a-f046e94a5c72
\.


--
-- Data for Name: review_assignment_audit_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.review_assignment_audit_items (id, public_id, assignment_id, audit_item_id, item_snapshot, created_at) FROM stdin;
\.


--
-- Data for Name: review_assignment_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.review_assignment_tags (id, assignment_id, tag_id, tag_snapshot, created_at, public_id) FROM stdin;
\.


--
-- Data for Name: review_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.review_assignments (id, task_id, assignee_id, decision, note, decided_at, public_id) FROM stdin;
\.


--
-- Data for Name: review_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.review_tasks (id, material_id, material_version_id, workflow_instance_id, stage_key, title, review_type, final_decision, machine_status, machine_result, machine_started_at, machine_completed_at, created_at, completed_at, canceled_at, canceled_by, cancel_reason, public_id) FROM stdin;
4	2	2	2	ai_scan	文本-20260712-170402-5908	MACHINE	PENDING	PENDING	\N	\N	\N	2026-07-12 17:04:08.380276+08	\N	\N	\N	\N	147ea7c3-a573-499e-ba79-1c8c327ae7eb
5	3	3	3	ai_scan	文本-20260712-232452-F2E8	MACHINE	PENDING	PENDING	\N	\N	\N	2026-07-12 23:25:14.383935+08	\N	\N	\N	\N	845c77d6-249c-4cbf-a272-bf2d78d77463
6	4	4	4	ai_scan	文本-20260713-021302-80F0	MACHINE	PENDING	PENDING	\N	\N	\N	2026-07-13 02:13:18.292781+08	\N	\N	\N	\N	d9a87211-cfaf-42c9-a930-16d600230733
1	1	1	1	ai_scan	文本-20260712-165606-E5AF	MACHINE	PENDING	COMPLETED	{"hits": [{"bbox": null, "page": null, "label": "absolute_claim", "quote": "最有效的保健品", "score": 0.98, "label_cn": "绝对化用语", "service_code": "text_detection_pro", "service_name": "通用文本审核", "timestamp_ms": null, "sensitive_grade": "S2"}, {"bbox": null, "page": null, "label": "medical_absolute_claim", "quote": "3天根治失眠", "score": 0.97, "label_cn": "医疗绝对化宣称", "service_code": "text_detection_pro", "service_name": "通用文本审核", "timestamp_ms": null, "sensitive_grade": "S2"}, {"bbox": null, "page": null, "label": "health_no_side_effect", "quote": "无任何副作用", "score": 0.95, "label_cn": "保健品无副作用宣称", "service_code": "text_detection_pro", "service_name": "通用文本审核", "timestamp_ms": null, "sensitive_grade": "S2"}, {"bbox": null, "page": null, "label": "absolute_price_claim", "quote": "全网最低价", "score": 0.94, "label_cn": "价格绝对化用语", "service_code": "text_detection_pro", "service_name": "通用文本审核", "timestamp_ms": null, "sensitive_grade": "S2"}], "summary": "文本含多处绝对化用语及保健品宣称疗效、无副作用等违规表述，违反《广告法》第九条、第十七条。", "rule_hits": [{"label": "absolute_claim", "matched": true, "rule_id": 44, "label_cn": "绝对化用语", "threshold": 0.5, "sensitive_grade": "S2"}, {"label": "medical_absolute_claim", "matched": true, "rule_id": 77, "label_cn": "医疗绝对化宣称", "threshold": 0.5, "sensitive_grade": "S2"}, {"label": "health_no_side_effect", "matched": true, "rule_id": 41, "label_cn": "保健品无副作用宣称", "threshold": 0.5, "sensitive_grade": "S2"}, {"label": "absolute_price_claim", "matched": true, "rule_id": 45, "label_cn": "价格绝对化用语", "threshold": 0.5, "sensitive_grade": "S2"}], "provenance": "openai", "risk_level": "高风险", "sensitive_level": "S2", "suggested_action": "rejected"}	2026-07-13 05:13:01.126116+08	2026-07-13 05:13:08.817501+08	2026-07-12 16:56:14.615336+08	\N	\N	\N	\N	b2e43525-bf75-487f-a75a-6df2a6359341
7	5	5	5	ai_scan	文本-20260713-024949-165F	MACHINE	PENDING	COMPLETED	{"hits": [], "summary": "文本内容仅为测试字符串，无任何违规风险。", "rule_hits": [], "provenance": "openai", "risk_level": "无风险", "sensitive_level": "S0", "suggested_action": "approved"}	2026-07-13 09:18:40.846385+08	2026-07-13 09:18:44.783953+08	2026-07-13 02:50:00.496667+08	\N	\N	\N	\N	852c489d-d567-47fb-b02f-71c2e64ed0db
\.


--
-- Data for Name: rule_sets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rule_sets (id, public_id, code, name, description, config, is_builtin, is_editable, locked_by_id, locked_at, created_by_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: service_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_categories (id, code, name, description, is_system, sort_order, is_active, created_at, updated_at, public_id) FROM stdin;
1	business	业务场景	常规业务场景下的检测服务	t	1	t	2026-07-12 16:30:57.31123+08	2026-07-12 16:30:57.31123+08	58105e49-c5fc-49ae-ad04-f7e6d4bc9c86
2	special	特殊场景	特殊业务场景下的检测服务	t	2	t	2026-07-12 16:30:57.31123+08	2026-07-12 16:30:57.31123+08	483bb3d6-8060-47b8-b191-9d2f17333355
3	aigc	AIGC场景	AIGC 相关检测服务	t	3	t	2026-07-12 16:30:57.31123+08	2026-07-12 16:30:57.31123+08	b761e96c-c02e-40b2-93fa-b44f95c56f43
4	bailian	百炼场景	百炼平台相关检测服务	t	4	t	2026-07-12 16:30:57.31123+08	2026-07-12 16:30:57.31123+08	860555e0-cebd-423d-a3ac-3baeed171b00
5	general	通用场景	通用内容安全检测服务	t	5	t	2026-07-12 16:30:57.31123+08	2026-07-12 16:30:57.31123+08	b8823404-5dfa-43aa-b4b5-2de1def67bd8
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.services (id, code, name, scope, description, is_active, is_custom, is_rule_package, category_id, created_at, updated_at, public_id) FROM stdin;
1	ad_compliance_detection_pro	广告法合规检测_专业版	SPECIAL	\N	t	f	t	2	2026-07-12 16:30:57.31123+08	2026-07-12 16:30:57.31123+08	bcf90321-0471-4a51-9992-be8f1174e26c
2	text_audit_pro	文本审核_专业版	BUSINESS	\N	t	f	t	1	2026-07-12 16:30:57.31123+08	2026-07-12 16:30:57.31123+08	5a9fa1ec-6946-4970-958c-5450ea10045f
3	general_content_audit	通用内容审核	GENERAL	\N	t	f	t	5	2026-07-12 16:30:57.31123+08	2026-07-12 16:30:57.31123+08	8c8fc181-4fc4-4f4b-b982-8bf9e29e582b
4	image_audit_pro	图片通用审核_专业版	GENERAL	\N	t	f	t	5	2026-07-12 16:30:57.31123+08	2026-07-12 16:30:57.31123+08	b7b8dceb-021b-4c1c-8f9c-e3a3d89873d4
5	audio_audit_pro	语音审核_专业版	GENERAL	\N	t	f	t	5	2026-07-12 16:30:57.31123+08	2026-07-12 16:30:57.31123+08	99577d7e-7603-424d-8491-519b7e5757b5
6	document_audit_pro	文档审核_专业版	GENERAL	\N	t	f	t	5	2026-07-12 16:30:57.31123+08	2026-07-12 16:30:57.31123+08	74571eaa-8957-4117-8e0c-060e6b0c0225
7	video_audit_pro	视频审核_专业版	GENERAL	\N	t	f	t	5	2026-07-12 16:30:57.31123+08	2026-07-12 16:30:57.31123+08	945e03f3-514e-464e-a85e-b80f22f6b44a
\.


--
-- Data for Name: strategies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.strategies (id, code, name, scope, description, is_active, effective_from, effective_until, definition, service_config, created_by_id, created_at, updated_at, public_id, rule_set_id, disposition_rule_id) FROM stdin;
1	1	默认策略	DEFAULT	当未配置其他策略、或所有策略均未启用/均未达生效时间时生效。	t	\N	\N	{}	{}	\N	2026-07-12 16:30:57.31123+08	2026-07-12 16:30:57.31123+08	6f0dd5dd-47db-448b-a818-ae0ae704f93a	\N	\N
2	2	test2	GENERAL	\N	t	\N	\N	{"services": [], "human_review": {"is_enabled": false, "risk_levels": [], "sample_ratio": null, "review_rule_id": null, "sensitive_levels": [], "auto_action_overrides": {}}, "doc_text_mode": "reuse_text", "audio_features": {"quality": {"no_speech": true}, "voiceprint": {"moaning": true}}, "doc_image_mode": "reuse_image", "voice_rule_mode": "reuse_text", "video_audio_mode": "reuse_audio", "video_frame_mode": "reuse_image", "video_frame_interval_sec": 5}	{}	5	2026-07-12 22:05:13.635187+08	2026-07-12 22:05:13.635187+08	d4d2c876-7df9-4360-88dd-1218b4f85b0d	\N	\N
\.


--
-- Data for Name: strategy_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.strategy_items (id, strategy_id, media_type, item_id, is_enabled, created_at, public_id) FROM stdin;
\.


--
-- Data for Name: strategy_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.strategy_points (id, strategy_id, media_type, item_id, point_id, is_enabled, created_at, public_id) FROM stdin;
1	2	image	7	20	t	2026-07-12 22:05:13.635187	825ab23b-e4d7-4c69-9b88-2f101d52ab85
\.


--
-- Data for Name: strategy_points_v2; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.strategy_points_v2 (id, public_id, rule_set_id, media_type, item_id, point_id, is_enabled, medium_threshold, high_threshold, linked_library_ids, created_at) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tags (id, code, name, name_en, description, domain, category, jurisdictions, industries, channels, knowledge_refs, evidence_refs, status, version, created_at, updated_at, deleted_at) FROM stdin;
05dfd8e9-e415-406f-a676-feef6ba4fcb4	tag_politics_figure	政治人物	\N	\N	POLITICS	FIGURE	["cn"]	[]	[]	[]	[]	ACTIVE	1	2026-07-12 16:30:57.31123	\N	\N
5126331e-9622-4fe6-906b-f3eac955d4a7	tag_politics_event	政治事件	\N	\N	POLITICS	EVENT	["cn"]	[]	[]	[]	[]	ACTIVE	1	2026-07-12 16:30:57.31123	\N	\N
2d6bb3af-bcf2-4006-b85b-9f6aa77494f5	tag_porn_image	色情图像	\N	\N	PORN	SCENE	["cn"]	[]	[]	[]	[]	ACTIVE	1	2026-07-12 16:30:57.31123	\N	\N
19a89980-cca1-44f5-9c3c-451d320f5855	tag_violence_scene	暴力场景	\N	\N	VIOLENCE	SCENE	["cn"]	[]	[]	[]	[]	ACTIVE	1	2026-07-12 16:30:57.31123	\N	\N
a09c75e5-cc8f-4d4e-ba15-5459d07ea681	tag_ads_absolute	绝对化用语	\N	\N	ADS_LAW	ABSOLUTE_TERM	["cn"]	[]	[]	[]	[]	ACTIVE	1	2026-07-12 16:30:57.31123	\N	\N
6d5896c4-2787-4661-89f8-31bd3d0a17a6	tag_ads_credential	缺失资质	\N	\N	ADS_LAW	CREDENTIAL	["cn"]	[]	[]	[]	[]	ACTIVE	1	2026-07-12 16:30:57.31123	\N	\N
94340f38-5246-451b-ad9c-27ed61462d03	tag_medical_claim	医疗宣称	\N	\N	MEDICAL	CLAIM	["cn"]	[]	[]	[]	[]	ACTIVE	1	2026-07-12 16:30:57.31123	\N	\N
5dd38b8f-2cc1-4d2e-9221-06dc186a90ee	tag_finance_promise	金融承诺	\N	\N	FINANCE	SLOGAN	["cn"]	[]	[]	[]	[]	ACTIVE	1	2026-07-12 16:30:57.31123	\N	\N
cc901ef6-52dd-4bbf-b910-a7f904e09dad	tag_minor_image	未成年人形象	\N	\N	MINOR	FIGURE	["cn"]	[]	[]	[]	[]	ACTIVE	1	2026-07-12 16:30:57.31123	\N	\N
887880ee-e464-4820-9a2e-ceb42446cbb6	tag_privacy_leak	隐私泄露	\N	\N	PRIVACY	SCENE	["cn"]	[]	[]	[]	[]	ACTIVE	1	2026-07-12 16:30:57.31123	\N	\N
4249b5a1-dd0b-44d1-ba7d-74f374515c54	tag_ip_logo	品牌 logo	\N	\N	IP	SYMBOL	["cn"]	[]	[]	[]	[]	ACTIVE	1	2026-07-12 16:30:57.31123	\N	\N
5abfb303-ee7b-4a38-9c15-36725882ba74	tag_fraud_claim	欺诈话术	\N	\N	FRAUD	CLAIM	["cn"]	[]	[]	[]	[]	ACTIVE	1	2026-07-12 16:30:57.31123	\N	\N
\.


--
-- Data for Name: trigger_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trigger_runs (id, trigger_id, source, started_at, finished_at, status, scanned_count, created_count, skipped_count, failed_count, error, details, public_id) FROM stdin;
\.


--
-- Data for Name: triggers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.triggers (id, code, name, trigger_type, is_enabled, spec, workflow_template_code, strategy_id, match_conditions, override_human_review, scan_interval_sec, last_run_at, next_run_at, run_count, last_error, created_by, created_at, updated_at, public_id) FROM stdin;
1	sample_full_scan	示例 - 全量文本巡检（未启用）	cron	f	{"cron": "0 2 * * *", "time": "02:00", "repeat": "daily", "timezone": "Asia/Shanghai"}	hybrid	\N	{"material_type": ["text"]}	\N	60	\N	\N	0	\N	\N	2026-07-12 16:30:57.31123+08	2026-07-12 16:30:57.31123+08	80de8e62-e116-46b7-9113-38d1462fd8e3
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, full_name, hashed_password, role, is_active, created_at, updated_at, public_id) FROM stdin;
1	admin@adreview.example.com	系统管理员	$2b$12$80xvV0XKixCKDDgBG/2Y5eyzYagKh79/ucSHZtGaRxGe1QRn6EpKu	ADMIN	t	2026-07-12 16:30:57.31123+08	2026-07-12 16:30:57.31123+08	f796bff7-1464-4850-b4d2-3400a5491fdf
2	reviewer@adreview.example.com	审核员 Alice	$2b$12$9rANmPHzIFdBGBOhUIFxf.ITqGkhcL79/038wyEcR1hie5YkpHu5i	REVIEWER	t	2026-07-12 16:30:57.31123+08	2026-07-12 16:30:57.31123+08	236c7fe3-b6e0-4f7e-97a4-61889eebc331
3	mlr@adreview.example.com	MLR 专家 Bob	$2b$12$1Zh37WthtpjWw58D/YAkyeWdJxbv3UpPUGcPCUFEIVkndnHy25FeG	MLR	t	2026-07-12 16:30:57.31123+08	2026-07-12 16:30:57.31123+08	6b551032-312c-441a-b08c-0d56ab32012c
4	submitter@adreview.example.com	提交者 Carol	$2b$12$XfINbFB8VXZRFDl4/9VyAODdiToCsGpwtZVIS1qqNpo4aeJrh/DDy	SUBMITTER	t	2026-07-12 16:30:57.31123+08	2026-07-12 16:30:57.31123+08	022d1643-eda3-4027-87c8-a8f8f494d649
5	superadmin@adreview.example.com	超级管理员	$2b$12$ZEjAfulORlUGePhl7HRXi.DXo5pEwa4zqcoqLGEmmfAgOMk5uo1ku	SUPERADMIN	t	2026-07-12 16:30:57.31123+08	2026-07-12 16:30:57.31123+08	7bb08ff0-17a4-4064-a3e0-cd4c31500cdd
\.


--
-- Data for Name: word_sets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.word_sets (id, code, name, "group", action, kind, words_text, description, is_active, ignored_services, created_at, updated_at, public_id) FROM stdin;
1	ws_default_blacklist	默认黑名单	KEYWORD	BLOCK	BLACKLIST	敏感词示例A\n敏感词示例B	全局默认禁止词集合	t	["ad_compliance_detection_pro"]	2026-07-12 16:30:57.31123	\N	39bff855-cb82-41af-a738-0dcb7ea94fa9
2	ws_default_whitelist	默认白名单	KEYWORD	BLOCK	WHITELIST	合规用语示例	全局默认放行词集合	t	[]	2026-07-12 16:30:57.31123	\N	ca46dd3f-41ad-4b56-ac42-e51b68f91497
3	ws_pharma_marketing	医药营销	KEYWORD	BLOCK	WHITELIST	\N	医药行业营销合规放行词	t	["ad_compliance_detection_pro"]	2026-07-12 16:30:57.31123	\N	ee272d84-81f4-4d84-acf6-09dfb8a29e98
4	ws_company_redline	公司红线	KEYWORD	BLOCK	BLACKLIST	\N	公司级违规红线词	t	["ad_compliance_detection_pro"]	2026-07-12 16:30:57.31123	\N	7328f3f7-01c4-4e9e-bd9c-3be6e109d257
5	ws_text_legal_terms	文本法律术语	KEYWORD	BLOCK	WHITELIST	依据相关法规\n本产品\n本公司	文本审核专用合法术语放行词	t	["text_audit_pro"]	2026-07-12 16:30:57.31123	\N	d17ce42a-b9af-4208-be29-5a5d4127705e
\.


--
-- Data for Name: workflow_instances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workflow_instances (id, material_id, material_version_id, template_id, state, current_stage_key, strategy_human_review, created_at, completed_at, public_id) FROM stdin;
2	2	2	4	running	ai_scan	{"is_enabled": false, "risk_levels": [], "sample_ratio": null, "review_rule_id": null, "sensitive_levels": [], "auto_action_overrides": {}}	2026-07-12 17:04:08.380276+08	\N	dab7d202-805f-43e9-8548-f0698e561dd1
3	3	3	4	running	ai_scan	{"is_enabled": false, "risk_levels": [], "sample_ratio": null, "review_rule_id": null, "sensitive_levels": [], "auto_action_overrides": {}}	2026-07-12 23:25:14.383935+08	\N	784d585b-d145-4edb-a50b-70ff57582364
4	4	4	4	running	ai_scan	{"is_enabled": false, "risk_levels": [], "sample_ratio": null, "review_rule_id": null, "sensitive_levels": [], "auto_action_overrides": {}}	2026-07-13 02:13:18.292781+08	\N	94842565-1fa9-4845-ac04-c63b303f46df
5	5	5	4	running	ai_scan	{"is_enabled": false, "risk_levels": [], "sample_ratio": null, "review_rule_id": null, "sensitive_levels": [], "auto_action_overrides": {}}	2026-07-13 02:50:00.496667+08	\N	4a24fc6c-a0fc-4cab-a201-2ae3c5807191
1	1	1	4	approved	ai_scan	null	2026-07-12 16:56:14.615336+08	2026-07-13 05:12:36.379173+08	7ca79318-6cd9-463f-bdde-113e8c5ef9c8
\.


--
-- Data for Name: workflow_nodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workflow_nodes (id, instance_id, "position", stage_key, name, required_role, mode, node_type, status, public_id) FROM stdin;
4	2	0	ai_scan	AI 智能扫描	system	single	machine	active	ccfbfe5a-58cb-4fde-a485-fec19db94446
5	2	1	initial	初审	reviewer	single	human	pending	1f333dbe-a7ed-498d-8ffc-c82fcea3b5b2
6	2	2	final	终审	reviewer	single	human	pending	5c0c09d7-b520-42c9-9ff4-0852c6a6983f
7	3	0	ai_scan	AI 智能扫描	system	single	machine	active	5f42207c-d0cb-48a9-8f48-74411dc11e11
8	3	1	initial	初审	reviewer	single	human	pending	1189e285-3eb6-4ed4-b899-9a88d6630a6f
9	3	2	final	终审	reviewer	single	human	pending	c2b542e5-030b-4b88-ac68-49f78984fe86
10	4	0	ai_scan	AI 智能扫描	system	single	machine	active	2cf8d25f-2831-41b2-877c-10f636d1b481
11	4	1	initial	初审	reviewer	single	human	pending	ec5a4203-4dea-4fb5-9994-9f3fd009542d
12	4	2	final	终审	reviewer	single	human	pending	a1b089a1-538c-4edc-805b-16b923aee0b7
13	5	0	ai_scan	AI 智能扫描	system	single	machine	active	e55af5a2-8d66-4641-86ee-1a7da80ee4a6
14	5	1	initial	初审	reviewer	single	human	pending	32a06a36-1d79-429a-b268-3fb88617f2ab
15	5	2	final	终审	reviewer	single	human	pending	f2f0e757-b5b8-4902-9be0-e5fe0964f253
1	1	0	ai_scan	AI 智能扫描	system	single	machine	approved	6362529c-2360-4ea8-8e2b-044c9984978d
2	1	1	initial	初审	reviewer	single	human	skipped	9e43c560-5d55-4a02-8992-c1b0e4ea9283
3	1	2	final	终审	reviewer	single	human	skipped	37c9b1a2-be4e-4f58-b3b7-ef19431b66cd
\.


--
-- Data for Name: workflow_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workflow_templates (id, code, name, description, definition, is_active, created_at, public_id) FROM stdin;
1	simple	两级审核	初审 → 终审	{"stages": [{"key": "initial", "mode": "single", "name": "初审", "role": "reviewer", "type": "human"}, {"key": "final", "mode": "single", "name": "终审", "role": "reviewer", "type": "human"}]}	t	2026-07-12 16:30:57.31123+08	a3c363ad-3493-4663-836c-ac854a1767e3
2	mlr	MLR 三级审核	初审 → MLR 联合审核 → 终审	{"stages": [{"key": "initial", "mode": "single", "name": "初审", "role": "reviewer", "type": "human"}, {"key": "mlr", "mode": "joint", "name": "MLR 联合审核", "role": "mlr", "type": "human"}, {"key": "final", "mode": "single", "name": "终审", "role": "reviewer", "type": "human"}]}	t	2026-07-12 16:30:57.31123+08	43ea371a-de5d-4533-a2de-7a3fcd1c78c1
3	auto_only	全自动机审	仅 AI 智能扫描，无人工审核	{"stages": [{"key": "ai_scan", "mode": "single", "name": "AI 智能扫描", "role": "system", "type": "machine", "config": {"services": ["text_detection_pro"], "timeout_seconds": 30}}]}	t	2026-07-12 16:30:57.31123+08	51b2a2c2-e200-4f46-92e8-7b09e3190434
4	hybrid	机审 + 人审	AI 智能扫描 → 根据风险等级决定是否人工审核	{"stages": [{"key": "ai_scan", "mode": "single", "name": "AI 智能扫描", "role": "system", "type": "machine", "config": {"services": ["text_detection_pro"], "timeout_seconds": 30}}, {"key": "initial", "mode": "single", "name": "初审", "role": "reviewer", "type": "human", "config": {"auto_assign": true}}, {"key": "final", "mode": "single", "name": "终审", "role": "reviewer", "type": "human", "config": {"auto_assign": true}}]}	t	2026-07-12 16:30:57.31123+08	57446f5f-713e-4f43-8a78-89eb72818d92
\.


--
-- Name: alert_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.alert_events_id_seq', 3, true);


--
-- Name: annotations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.annotations_id_seq', 1, false);


--
-- Name: audit_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_events_id_seq', 19, true);


--
-- Name: audit_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_items_id_seq', 43, true);


--
-- Name: audit_points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_points_id_seq', 92, true);


--
-- Name: detection_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.detection_rules_id_seq', 18, true);


--
-- Name: disposition_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.disposition_rules_id_seq', 1, false);


--
-- Name: human_review_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.human_review_configs_id_seq', 2, true);


--
-- Name: image_set_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.image_set_items_id_seq', 1, false);


--
-- Name: image_sets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.image_sets_id_seq', 1, false);


--
-- Name: libraries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.libraries_id_seq', 20, true);


--
-- Name: library_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.library_items_id_seq', 2, true);


--
-- Name: llm_calls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.llm_calls_id_seq', 3, true);


--
-- Name: material_package_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.material_package_items_id_seq', 1, false);


--
-- Name: material_packages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.material_packages_id_seq', 1, false);


--
-- Name: material_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.material_versions_id_seq', 2827, true);


--
-- Name: materials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.materials_id_seq', 2827, true);


--
-- Name: ops_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ops_log_id_seq', 14, true);


--
-- Name: review_assignment_audit_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.review_assignment_audit_items_id_seq', 1, false);


--
-- Name: review_assignment_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.review_assignment_tags_id_seq', 267, true);


--
-- Name: review_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.review_assignments_id_seq', 3642, true);


--
-- Name: review_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.review_tasks_id_seq', 2829, true);


--
-- Name: rule_sets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rule_sets_id_seq', 1, false);


--
-- Name: service_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_categories_id_seq', 5, true);


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.services_id_seq', 7, true);


--
-- Name: strategies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.strategies_id_seq', 3, true);


--
-- Name: strategy_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.strategy_items_id_seq', 1, false);


--
-- Name: strategy_points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.strategy_points_id_seq', 2, true);


--
-- Name: strategy_points_v2_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.strategy_points_v2_id_seq', 1, false);


--
-- Name: trigger_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.trigger_runs_id_seq', 1, false);


--
-- Name: triggers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.triggers_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- Name: word_sets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.word_sets_id_seq', 5, true);


--
-- Name: workflow_instances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.workflow_instances_id_seq', 2827, true);


--
-- Name: workflow_nodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.workflow_nodes_id_seq', 15, true);


--
-- Name: workflow_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.workflow_templates_id_seq', 4, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: alert_events alert_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_events
    ADD CONSTRAINT alert_events_pkey PRIMARY KEY (id);


--
-- Name: annotations annotations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.annotations
    ADD CONSTRAINT annotations_pkey PRIMARY KEY (id);


--
-- Name: audit_events audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_pkey PRIMARY KEY (id);


--
-- Name: audit_items audit_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_items
    ADD CONSTRAINT audit_items_pkey PRIMARY KEY (id);


--
-- Name: audit_point_libraries audit_point_libraries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_point_libraries
    ADD CONSTRAINT audit_point_libraries_pkey PRIMARY KEY (audit_point_id, library_id);


--
-- Name: audit_points audit_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_points
    ADD CONSTRAINT audit_points_pkey PRIMARY KEY (id);


--
-- Name: detection_rules detection_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detection_rules
    ADD CONSTRAINT detection_rules_pkey PRIMARY KEY (id);


--
-- Name: disposition_rules disposition_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disposition_rules
    ADD CONSTRAINT disposition_rules_pkey PRIMARY KEY (id);


--
-- Name: disposition_rules disposition_rules_public_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disposition_rules
    ADD CONSTRAINT disposition_rules_public_id_key UNIQUE (public_id);


--
-- Name: human_review_configs human_review_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.human_review_configs
    ADD CONSTRAINT human_review_configs_pkey PRIMARY KEY (id);


--
-- Name: image_set_items image_set_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.image_set_items
    ADD CONSTRAINT image_set_items_pkey PRIMARY KEY (id);


--
-- Name: image_sets image_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.image_sets
    ADD CONSTRAINT image_sets_pkey PRIMARY KEY (id);


--
-- Name: libraries libraries_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.libraries
    ADD CONSTRAINT libraries_code_key UNIQUE (code);


--
-- Name: libraries libraries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.libraries
    ADD CONSTRAINT libraries_pkey PRIMARY KEY (id);


--
-- Name: library_item_references library_item_references_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_item_references
    ADD CONSTRAINT library_item_references_pkey PRIMARY KEY (item_id, library_id);


--
-- Name: library_items library_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_items
    ADD CONSTRAINT library_items_pkey PRIMARY KEY (id);


--
-- Name: llm_calls llm_calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_calls
    ADD CONSTRAINT llm_calls_pkey PRIMARY KEY (id);


--
-- Name: material_package_items material_package_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_package_items
    ADD CONSTRAINT material_package_items_pkey PRIMARY KEY (id);


--
-- Name: material_packages material_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_packages
    ADD CONSTRAINT material_packages_pkey PRIMARY KEY (id);


--
-- Name: material_versions material_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_versions
    ADD CONSTRAINT material_versions_pkey PRIMARY KEY (id);


--
-- Name: materials materials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.materials
    ADD CONSTRAINT materials_pkey PRIMARY KEY (id);


--
-- Name: ops_log ops_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ops_log
    ADD CONSTRAINT ops_log_pkey PRIMARY KEY (id);


--
-- Name: review_assignment_audit_items review_assignment_audit_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_assignment_audit_items
    ADD CONSTRAINT review_assignment_audit_items_pkey PRIMARY KEY (id);


--
-- Name: review_assignment_tags review_assignment_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_assignment_tags
    ADD CONSTRAINT review_assignment_tags_pkey PRIMARY KEY (id);


--
-- Name: review_assignments review_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_assignments
    ADD CONSTRAINT review_assignments_pkey PRIMARY KEY (id);


--
-- Name: review_tasks review_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_tasks
    ADD CONSTRAINT review_tasks_pkey PRIMARY KEY (id);


--
-- Name: rule_sets rule_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_sets
    ADD CONSTRAINT rule_sets_pkey PRIMARY KEY (id);


--
-- Name: rule_sets rule_sets_public_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_sets
    ADD CONSTRAINT rule_sets_public_id_key UNIQUE (public_id);


--
-- Name: service_categories service_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_categories
    ADD CONSTRAINT service_categories_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: strategies strategies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategies
    ADD CONSTRAINT strategies_pkey PRIMARY KEY (id);


--
-- Name: strategy_items strategy_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_items
    ADD CONSTRAINT strategy_items_pkey PRIMARY KEY (id);


--
-- Name: strategy_points strategy_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_points
    ADD CONSTRAINT strategy_points_pkey PRIMARY KEY (id);


--
-- Name: strategy_points_v2 strategy_points_v2_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_points_v2
    ADD CONSTRAINT strategy_points_v2_pkey PRIMARY KEY (id);


--
-- Name: strategy_points_v2 strategy_points_v2_public_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_points_v2
    ADD CONSTRAINT strategy_points_v2_public_id_key UNIQUE (public_id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: trigger_runs trigger_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trigger_runs
    ADD CONSTRAINT trigger_runs_pkey PRIMARY KEY (id);


--
-- Name: triggers triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.triggers
    ADD CONSTRAINT triggers_pkey PRIMARY KEY (id);


--
-- Name: audit_items uq_audit_item_pkg_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_items
    ADD CONSTRAINT uq_audit_item_pkg_code UNIQUE (package_code, code);


--
-- Name: audit_points uq_audit_point_pkg_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_points
    ADD CONSTRAINT uq_audit_point_pkg_code UNIQUE (package_code, code);


--
-- Name: disposition_rules uq_disposition_rules_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disposition_rules
    ADD CONSTRAINT uq_disposition_rules_code UNIQUE (code);


--
-- Name: llm_calls uq_llm_calls_public_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_calls
    ADD CONSTRAINT uq_llm_calls_public_id UNIQUE (public_id);


--
-- Name: material_package_items uq_package_item; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_package_items
    ADD CONSTRAINT uq_package_item UNIQUE (package_id, material_id);


--
-- Name: review_assignment_audit_items uq_raai_public_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_assignment_audit_items
    ADD CONSTRAINT uq_raai_public_id UNIQUE (public_id);


--
-- Name: strategy_points_v2 uq_rs_point_v2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_points_v2
    ADD CONSTRAINT uq_rs_point_v2 UNIQUE (rule_set_id, point_id);


--
-- Name: rule_sets uq_rule_sets_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_sets
    ADD CONSTRAINT uq_rule_sets_code UNIQUE (code);


--
-- Name: strategy_items uq_strategy_item; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_items
    ADD CONSTRAINT uq_strategy_item UNIQUE (strategy_id, item_id);


--
-- Name: strategy_points uq_strategy_point; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_points
    ADD CONSTRAINT uq_strategy_point UNIQUE (strategy_id, point_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: word_sets word_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.word_sets
    ADD CONSTRAINT word_sets_pkey PRIMARY KEY (id);


--
-- Name: workflow_instances workflow_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_instances
    ADD CONSTRAINT workflow_instances_pkey PRIMARY KEY (id);


--
-- Name: workflow_nodes workflow_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_nodes
    ADD CONSTRAINT workflow_nodes_pkey PRIMARY KEY (id);


--
-- Name: workflow_templates workflow_templates_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_templates
    ADD CONSTRAINT workflow_templates_code_key UNIQUE (code);


--
-- Name: workflow_templates workflow_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_templates
    ADD CONSTRAINT workflow_templates_pkey PRIMARY KEY (id);


--
-- Name: ix_alert_events_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_alert_events_created_at ON public.alert_events USING btree (created_at);


--
-- Name: ix_alert_events_metric; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_alert_events_metric ON public.alert_events USING btree (metric);


--
-- Name: ix_alert_events_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_alert_events_public_id ON public.alert_events USING btree (public_id);


--
-- Name: ix_alert_events_rule_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_alert_events_rule_code ON public.alert_events USING btree (rule_code);


--
-- Name: ix_alert_events_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_alert_events_status ON public.alert_events USING btree (status);


--
-- Name: ix_alert_rule_window; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_alert_rule_window ON public.alert_events USING btree (rule_code, window_start, window_end);


--
-- Name: ix_alert_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_alert_status_created ON public.alert_events USING btree (status, created_at);


--
-- Name: ix_annotations_material_version_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_annotations_material_version_id ON public.annotations USING btree (material_version_id);


--
-- Name: ix_annotations_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_annotations_public_id ON public.annotations USING btree (public_id);


--
-- Name: ix_audit_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_entity ON public.audit_events USING btree (entity_type, entity_id);


--
-- Name: ix_audit_events_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_events_action ON public.audit_events USING btree (action);


--
-- Name: ix_audit_events_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_events_created_at ON public.audit_events USING btree (created_at);


--
-- Name: ix_audit_events_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_events_entity_id ON public.audit_events USING btree (entity_id);


--
-- Name: ix_audit_events_entity_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_events_entity_type ON public.audit_events USING btree (entity_type);


--
-- Name: ix_audit_events_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_audit_events_public_id ON public.audit_events USING btree (public_id);


--
-- Name: ix_audit_items_package_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_items_package_code ON public.audit_items USING btree (package_code);


--
-- Name: ix_audit_items_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_audit_items_public_id ON public.audit_items USING btree (public_id);


--
-- Name: ix_audit_point_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_point_item ON public.audit_points USING btree (item_id);


--
-- Name: ix_audit_point_libraries_lib; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_point_libraries_lib ON public.audit_point_libraries USING btree (library_id);


--
-- Name: ix_audit_points_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_points_item_id ON public.audit_points USING btree (item_id);


--
-- Name: ix_audit_points_package_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_points_package_code ON public.audit_points USING btree (package_code);


--
-- Name: ix_audit_points_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_audit_points_public_id ON public.audit_points USING btree (public_id);


--
-- Name: ix_detection_rules_audit_point_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_detection_rules_audit_point_id ON public.detection_rules USING btree (audit_point_id);


--
-- Name: ix_detection_rules_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_detection_rules_public_id ON public.detection_rules USING btree (public_id);


--
-- Name: ix_detection_rules_service_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_detection_rules_service_code ON public.detection_rules USING btree (service_code);


--
-- Name: ix_detection_rules_service_label; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_detection_rules_service_label ON public.detection_rules USING btree (service_code, label);


--
-- Name: ix_disposition_rules_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_disposition_rules_public_id ON public.disposition_rules USING btree (public_id);


--
-- Name: ix_human_review_configs_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_human_review_configs_public_id ON public.human_review_configs USING btree (public_id);


--
-- Name: ix_human_review_configs_service_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_human_review_configs_service_code ON public.human_review_configs USING btree (service_code);


--
-- Name: ix_image_set_items_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_image_set_items_public_id ON public.image_set_items USING btree (public_id);


--
-- Name: ix_image_set_items_set_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_image_set_items_set_id ON public.image_set_items USING btree (set_id);


--
-- Name: ix_image_sets_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_image_sets_action ON public.image_sets USING btree (action);


--
-- Name: ix_image_sets_action_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_image_sets_action_active ON public.image_sets USING btree (action, is_active);


--
-- Name: ix_image_sets_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_image_sets_code ON public.image_sets USING btree (code);


--
-- Name: ix_image_sets_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_image_sets_group ON public.image_sets USING btree ("group");


--
-- Name: ix_image_sets_group_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_image_sets_group_action ON public.image_sets USING btree ("group", action);


--
-- Name: ix_image_sets_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_image_sets_kind ON public.image_sets USING btree (kind);


--
-- Name: ix_image_sets_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_image_sets_public_id ON public.image_sets USING btree (public_id);


--
-- Name: ix_libraries_effective_range; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_libraries_effective_range ON public.libraries USING btree (effective_from, effective_until);


--
-- Name: ix_libraries_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_libraries_public_id ON public.libraries USING btree (public_id);


--
-- Name: ix_libraries_type_kind_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_libraries_type_kind_active ON public.libraries USING btree (library_type, kind, is_deleted, is_active);


--
-- Name: ix_library_item_references_library; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_library_item_references_library ON public.library_item_references USING btree (library_id);


--
-- Name: ix_library_items_library_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_library_items_library_active ON public.library_items USING btree (library_id, is_deleted);


--
-- Name: ix_library_items_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_library_items_public_id ON public.library_items USING btree (public_id);


--
-- Name: ix_library_items_sha; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_library_items_sha ON public.library_items USING btree (sha256);


--
-- Name: ix_library_items_word; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_library_items_word ON public.library_items USING btree (word);


--
-- Name: ix_llm_calls_correlation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_llm_calls_correlation_id ON public.llm_calls USING btree (correlation_id);


--
-- Name: ix_llm_calls_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_llm_calls_created_at ON public.llm_calls USING btree (created_at);


--
-- Name: ix_llm_calls_ok; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_llm_calls_ok ON public.llm_calls USING btree (ok);


--
-- Name: ix_llm_calls_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_llm_calls_public_id ON public.llm_calls USING btree (public_id);


--
-- Name: ix_llm_calls_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_llm_calls_task_id ON public.llm_calls USING btree (task_id);


--
-- Name: ix_material_package_items_material_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_material_package_items_material_id ON public.material_package_items USING btree (material_id);


--
-- Name: ix_material_package_items_package_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_material_package_items_package_id ON public.material_package_items USING btree (package_id);


--
-- Name: ix_material_package_items_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_material_package_items_public_id ON public.material_package_items USING btree (public_id);


--
-- Name: ix_material_packages_creator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_material_packages_creator_id ON public.material_packages USING btree (creator_id);


--
-- Name: ix_material_packages_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_material_packages_public_id ON public.material_packages USING btree (public_id);


--
-- Name: ix_material_packages_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_material_packages_status ON public.material_packages USING btree (status);


--
-- Name: ix_material_version_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_material_version_unique ON public.material_versions USING btree (material_id, version_no);


--
-- Name: ix_material_versions_material_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_material_versions_material_id ON public.material_versions USING btree (material_id);


--
-- Name: ix_material_versions_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_material_versions_public_id ON public.material_versions USING btree (public_id);


--
-- Name: ix_materials_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_materials_public_id ON public.materials USING btree (public_id);


--
-- Name: ix_materials_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_materials_status ON public.materials USING btree (status);


--
-- Name: ix_materials_status_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_materials_status_type ON public.materials USING btree (status, material_type);


--
-- Name: ix_materials_submitter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_materials_submitter_id ON public.materials USING btree (submitter_id);


--
-- Name: ix_ops_log_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ops_log_action ON public.ops_log USING btree (action);


--
-- Name: ix_ops_log_action_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ops_log_action_created_at ON public.ops_log USING btree (action, created_at);


--
-- Name: ix_ops_log_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ops_log_created_at ON public.ops_log USING btree (created_at);


--
-- Name: ix_ops_log_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_ops_log_public_id ON public.ops_log USING btree (public_id);


--
-- Name: ix_ops_log_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ops_log_status ON public.ops_log USING btree (status);


--
-- Name: ix_raai_assignment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_raai_assignment_id ON public.review_assignment_audit_items USING btree (assignment_id);


--
-- Name: ix_raai_assignment_item; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_raai_assignment_item ON public.review_assignment_audit_items USING btree (assignment_id, audit_item_id);


--
-- Name: ix_raai_audit_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_raai_audit_item_id ON public.review_assignment_audit_items USING btree (audit_item_id);


--
-- Name: ix_raai_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_raai_public_id ON public.review_assignment_audit_items USING btree (public_id);


--
-- Name: ix_rat_assignment_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_rat_assignment_tag ON public.review_assignment_tags USING btree (assignment_id, tag_id);


--
-- Name: ix_review_assignment_tags_assignment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_review_assignment_tags_assignment_id ON public.review_assignment_tags USING btree (assignment_id);


--
-- Name: ix_review_assignment_tags_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_review_assignment_tags_public_id ON public.review_assignment_tags USING btree (public_id);


--
-- Name: ix_review_assignment_tags_tag_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_review_assignment_tags_tag_id ON public.review_assignment_tags USING btree (tag_id);


--
-- Name: ix_review_assignments_assignee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_review_assignments_assignee_id ON public.review_assignments USING btree (assignee_id);


--
-- Name: ix_review_assignments_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_review_assignments_public_id ON public.review_assignments USING btree (public_id);


--
-- Name: ix_review_assignments_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_review_assignments_task_id ON public.review_assignments USING btree (task_id);


--
-- Name: ix_review_task_stage; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_review_task_stage ON public.review_tasks USING btree (workflow_instance_id, stage_key);


--
-- Name: ix_review_tasks_canceled_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_review_tasks_canceled_at ON public.review_tasks USING btree (canceled_at);


--
-- Name: ix_review_tasks_final_decision; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_review_tasks_final_decision ON public.review_tasks USING btree (final_decision);


--
-- Name: ix_review_tasks_machine_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_review_tasks_machine_status ON public.review_tasks USING btree (machine_status);


--
-- Name: ix_review_tasks_material_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_review_tasks_material_id ON public.review_tasks USING btree (material_id);


--
-- Name: ix_review_tasks_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_review_tasks_public_id ON public.review_tasks USING btree (public_id);


--
-- Name: ix_review_tasks_review_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_review_tasks_review_type ON public.review_tasks USING btree (review_type);


--
-- Name: ix_review_tasks_workflow_instance_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_review_tasks_workflow_instance_id ON public.review_tasks USING btree (workflow_instance_id);


--
-- Name: ix_rule_sets_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_rule_sets_public_id ON public.rule_sets USING btree (public_id);


--
-- Name: ix_service_categories_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_service_categories_code ON public.service_categories USING btree (code);


--
-- Name: ix_service_categories_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_service_categories_public_id ON public.service_categories USING btree (public_id);


--
-- Name: ix_service_scope_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_service_scope_active ON public.services USING btree (scope, is_active);


--
-- Name: ix_services_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_services_category_id ON public.services USING btree (category_id);


--
-- Name: ix_services_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_services_code ON public.services USING btree (code);


--
-- Name: ix_services_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_services_public_id ON public.services USING btree (public_id);


--
-- Name: ix_services_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_services_scope ON public.services USING btree (scope);


--
-- Name: ix_sp_v2_rs; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sp_v2_rs ON public.strategy_points_v2 USING btree (rule_set_id);


--
-- Name: ix_strategies_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_strategies_code ON public.strategies USING btree (code);


--
-- Name: ix_strategies_disposition_rule_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_strategies_disposition_rule_id ON public.strategies USING btree (disposition_rule_id);


--
-- Name: ix_strategies_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_strategies_public_id ON public.strategies USING btree (public_id);


--
-- Name: ix_strategies_rule_set_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_strategies_rule_set_id ON public.strategies USING btree (rule_set_id);


--
-- Name: ix_strategies_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_strategies_scope ON public.strategies USING btree (scope);


--
-- Name: ix_strategy_items_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_strategy_items_public_id ON public.strategy_items USING btree (public_id);


--
-- Name: ix_strategy_items_strategy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_strategy_items_strategy ON public.strategy_items USING btree (strategy_id);


--
-- Name: ix_strategy_items_strategy_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_strategy_items_strategy_id ON public.strategy_items USING btree (strategy_id);


--
-- Name: ix_strategy_points_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_strategy_points_public_id ON public.strategy_points USING btree (public_id);


--
-- Name: ix_strategy_points_strategy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_strategy_points_strategy ON public.strategy_points USING btree (strategy_id);


--
-- Name: ix_strategy_points_strategy_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_strategy_points_strategy_id ON public.strategy_points USING btree (strategy_id);


--
-- Name: ix_strategy_points_v2_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_strategy_points_v2_public_id ON public.strategy_points_v2 USING btree (public_id);


--
-- Name: ix_tag_domain_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tag_domain_category ON public.tags USING btree (domain, category);


--
-- Name: ix_tags_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tags_category ON public.tags USING btree (category);


--
-- Name: ix_tags_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_tags_code ON public.tags USING btree (code);


--
-- Name: ix_tags_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tags_deleted_at ON public.tags USING btree (deleted_at);


--
-- Name: ix_tags_domain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tags_domain ON public.tags USING btree (domain);


--
-- Name: ix_tags_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tags_status ON public.tags USING btree (status);


--
-- Name: ix_trigger_runs_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_trigger_runs_public_id ON public.trigger_runs USING btree (public_id);


--
-- Name: ix_trigger_runs_started; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_trigger_runs_started ON public.trigger_runs USING btree (started_at);


--
-- Name: ix_trigger_runs_trigger; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_trigger_runs_trigger ON public.trigger_runs USING btree (trigger_id, started_at);


--
-- Name: ix_triggers_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_triggers_code ON public.triggers USING btree (code);


--
-- Name: ix_triggers_enabled_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_triggers_enabled_type ON public.triggers USING btree (is_enabled, trigger_type);


--
-- Name: ix_triggers_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_triggers_public_id ON public.triggers USING btree (public_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_public_id ON public.users USING btree (public_id);


--
-- Name: ix_word_sets_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_word_sets_action ON public.word_sets USING btree (action);


--
-- Name: ix_word_sets_action_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_word_sets_action_active ON public.word_sets USING btree (action, is_active);


--
-- Name: ix_word_sets_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_word_sets_code ON public.word_sets USING btree (code);


--
-- Name: ix_word_sets_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_word_sets_group ON public.word_sets USING btree ("group");


--
-- Name: ix_word_sets_group_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_word_sets_group_action ON public.word_sets USING btree ("group", action);


--
-- Name: ix_word_sets_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_word_sets_kind ON public.word_sets USING btree (kind);


--
-- Name: ix_word_sets_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_word_sets_public_id ON public.word_sets USING btree (public_id);


--
-- Name: ix_workflow_instances_material_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_instances_material_id ON public.workflow_instances USING btree (material_id);


--
-- Name: ix_workflow_instances_material_version_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_instances_material_version_id ON public.workflow_instances USING btree (material_version_id);


--
-- Name: ix_workflow_instances_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_workflow_instances_public_id ON public.workflow_instances USING btree (public_id);


--
-- Name: ix_workflow_instances_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_instances_state ON public.workflow_instances USING btree (state);


--
-- Name: ix_workflow_nodes_instance_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_nodes_instance_id ON public.workflow_nodes USING btree (instance_id);


--
-- Name: ix_workflow_nodes_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_workflow_nodes_public_id ON public.workflow_nodes USING btree (public_id);


--
-- Name: ix_workflow_nodes_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_nodes_status ON public.workflow_nodes USING btree (status);


--
-- Name: ix_workflow_templates_public_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_workflow_templates_public_id ON public.workflow_templates USING btree (public_id);


--
-- Name: alert_events alert_events_ack_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_events
    ADD CONSTRAINT alert_events_ack_by_fkey FOREIGN KEY (ack_by) REFERENCES public.users(id);


--
-- Name: annotations annotations_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.annotations
    ADD CONSTRAINT annotations_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: annotations annotations_material_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.annotations
    ADD CONSTRAINT annotations_material_version_id_fkey FOREIGN KEY (material_version_id) REFERENCES public.material_versions(id) ON DELETE CASCADE;


--
-- Name: annotations annotations_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.annotations
    ADD CONSTRAINT annotations_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.annotations(id);


--
-- Name: audit_events audit_events_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: audit_items audit_items_package_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_items
    ADD CONSTRAINT audit_items_package_code_fkey FOREIGN KEY (package_code) REFERENCES public.services(code);


--
-- Name: audit_point_libraries audit_point_libraries_audit_point_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_point_libraries
    ADD CONSTRAINT audit_point_libraries_audit_point_id_fkey FOREIGN KEY (audit_point_id) REFERENCES public.audit_points(id) ON DELETE CASCADE;


--
-- Name: audit_point_libraries audit_point_libraries_library_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_point_libraries
    ADD CONSTRAINT audit_point_libraries_library_id_fkey FOREIGN KEY (library_id) REFERENCES public.libraries(id) ON DELETE CASCADE;


--
-- Name: audit_points audit_points_custom_library_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_points
    ADD CONSTRAINT audit_points_custom_library_id_fkey FOREIGN KEY (custom_library_id) REFERENCES public.libraries(id);


--
-- Name: audit_points audit_points_custom_reply_library_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_points
    ADD CONSTRAINT audit_points_custom_reply_library_id_fkey FOREIGN KEY (custom_reply_library_id) REFERENCES public.libraries(id);


--
-- Name: audit_points audit_points_custom_wordset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_points
    ADD CONSTRAINT audit_points_custom_wordset_id_fkey FOREIGN KEY (custom_wordset_id) REFERENCES public.word_sets(id);


--
-- Name: audit_points audit_points_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_points
    ADD CONSTRAINT audit_points_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.audit_items(id);


--
-- Name: audit_points audit_points_package_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_points
    ADD CONSTRAINT audit_points_package_code_fkey FOREIGN KEY (package_code) REFERENCES public.services(code);


--
-- Name: detection_rules detection_rules_audit_point_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detection_rules
    ADD CONSTRAINT detection_rules_audit_point_id_fkey FOREIGN KEY (audit_point_id) REFERENCES public.audit_points(id);


--
-- Name: detection_rules detection_rules_custom_wordset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detection_rules
    ADD CONSTRAINT detection_rules_custom_wordset_id_fkey FOREIGN KEY (custom_wordset_id) REFERENCES public.word_sets(id);


--
-- Name: detection_rules detection_rules_service_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detection_rules
    ADD CONSTRAINT detection_rules_service_code_fkey FOREIGN KEY (service_code) REFERENCES public.services(code);


--
-- Name: disposition_rules disposition_rules_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disposition_rules
    ADD CONSTRAINT disposition_rules_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: disposition_rules disposition_rules_locked_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disposition_rules
    ADD CONSTRAINT disposition_rules_locked_by_id_fkey FOREIGN KEY (locked_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: disposition_rules disposition_rules_review_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.disposition_rules
    ADD CONSTRAINT disposition_rules_review_rule_id_fkey FOREIGN KEY (review_rule_id) REFERENCES public.workflow_templates(id) ON DELETE SET NULL;


--
-- Name: review_assignment_audit_items fk_raai_assignment; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_assignment_audit_items
    ADD CONSTRAINT fk_raai_assignment FOREIGN KEY (assignment_id) REFERENCES public.review_assignments(id) ON DELETE CASCADE;


--
-- Name: review_assignment_audit_items fk_raai_audit_item; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_assignment_audit_items
    ADD CONSTRAINT fk_raai_audit_item FOREIGN KEY (audit_item_id) REFERENCES public.audit_items(id) ON DELETE RESTRICT;


--
-- Name: strategies fk_strategies_disposition_rule; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategies
    ADD CONSTRAINT fk_strategies_disposition_rule FOREIGN KEY (disposition_rule_id) REFERENCES public.disposition_rules(id) ON DELETE RESTRICT;


--
-- Name: strategies fk_strategies_rule_set; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategies
    ADD CONSTRAINT fk_strategies_rule_set FOREIGN KEY (rule_set_id) REFERENCES public.rule_sets(id) ON DELETE RESTRICT;


--
-- Name: human_review_configs human_review_configs_review_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.human_review_configs
    ADD CONSTRAINT human_review_configs_review_rule_id_fkey FOREIGN KEY (review_rule_id) REFERENCES public.workflow_templates(id);


--
-- Name: human_review_configs human_review_configs_service_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.human_review_configs
    ADD CONSTRAINT human_review_configs_service_code_fkey FOREIGN KEY (service_code) REFERENCES public.services(code);


--
-- Name: image_set_items image_set_items_set_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.image_set_items
    ADD CONSTRAINT image_set_items_set_id_fkey FOREIGN KEY (set_id) REFERENCES public.image_sets(id) ON DELETE CASCADE;


--
-- Name: library_item_references library_item_references_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_item_references
    ADD CONSTRAINT library_item_references_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.library_items(id) ON DELETE CASCADE;


--
-- Name: library_item_references library_item_references_library_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_item_references
    ADD CONSTRAINT library_item_references_library_id_fkey FOREIGN KEY (library_id) REFERENCES public.libraries(id) ON DELETE CASCADE;


--
-- Name: library_items library_items_library_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.library_items
    ADD CONSTRAINT library_items_library_id_fkey FOREIGN KEY (library_id) REFERENCES public.libraries(id) ON DELETE CASCADE;


--
-- Name: llm_calls llm_calls_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_calls
    ADD CONSTRAINT llm_calls_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.review_tasks(id) ON DELETE SET NULL;


--
-- Name: llm_calls llm_calls_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_calls
    ADD CONSTRAINT llm_calls_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.material_versions(id) ON DELETE SET NULL;


--
-- Name: material_package_items material_package_items_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_package_items
    ADD CONSTRAINT material_package_items_material_id_fkey FOREIGN KEY (material_id) REFERENCES public.materials(id) ON DELETE CASCADE;


--
-- Name: material_package_items material_package_items_package_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_package_items
    ADD CONSTRAINT material_package_items_package_id_fkey FOREIGN KEY (package_id) REFERENCES public.material_packages(id) ON DELETE CASCADE;


--
-- Name: material_package_items material_package_items_review_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_package_items
    ADD CONSTRAINT material_package_items_review_task_id_fkey FOREIGN KEY (review_task_id) REFERENCES public.review_tasks(id);


--
-- Name: material_packages material_packages_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_packages
    ADD CONSTRAINT material_packages_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: material_versions material_versions_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_versions
    ADD CONSTRAINT material_versions_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: material_versions material_versions_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_versions
    ADD CONSTRAINT material_versions_material_id_fkey FOREIGN KEY (material_id) REFERENCES public.materials(id) ON DELETE CASCADE;


--
-- Name: materials materials_current_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.materials
    ADD CONSTRAINT materials_current_version_id_fkey FOREIGN KEY (current_version_id) REFERENCES public.material_versions(id);


--
-- Name: materials materials_submitter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.materials
    ADD CONSTRAINT materials_submitter_id_fkey FOREIGN KEY (submitter_id) REFERENCES public.users(id);


--
-- Name: review_assignment_tags review_assignment_tags_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_assignment_tags
    ADD CONSTRAINT review_assignment_tags_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.review_assignments(id) ON DELETE CASCADE;


--
-- Name: review_assignments review_assignments_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_assignments
    ADD CONSTRAINT review_assignments_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id);


--
-- Name: review_assignments review_assignments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_assignments
    ADD CONSTRAINT review_assignments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.review_tasks(id) ON DELETE CASCADE;


--
-- Name: review_tasks review_tasks_canceled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_tasks
    ADD CONSTRAINT review_tasks_canceled_by_fkey FOREIGN KEY (canceled_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: review_tasks review_tasks_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_tasks
    ADD CONSTRAINT review_tasks_material_id_fkey FOREIGN KEY (material_id) REFERENCES public.materials(id) ON DELETE CASCADE;


--
-- Name: review_tasks review_tasks_material_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_tasks
    ADD CONSTRAINT review_tasks_material_version_id_fkey FOREIGN KEY (material_version_id) REFERENCES public.material_versions(id) ON DELETE CASCADE;


--
-- Name: review_tasks review_tasks_workflow_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_tasks
    ADD CONSTRAINT review_tasks_workflow_instance_id_fkey FOREIGN KEY (workflow_instance_id) REFERENCES public.workflow_instances(id) ON DELETE CASCADE;


--
-- Name: rule_sets rule_sets_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_sets
    ADD CONSTRAINT rule_sets_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: rule_sets rule_sets_locked_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_sets
    ADD CONSTRAINT rule_sets_locked_by_id_fkey FOREIGN KEY (locked_by_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: services services_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.service_categories(id);


--
-- Name: strategies strategies_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategies
    ADD CONSTRAINT strategies_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: strategy_items strategy_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_items
    ADD CONSTRAINT strategy_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.audit_items(id) ON DELETE CASCADE;


--
-- Name: strategy_items strategy_items_strategy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_items
    ADD CONSTRAINT strategy_items_strategy_id_fkey FOREIGN KEY (strategy_id) REFERENCES public.strategies(id) ON DELETE CASCADE;


--
-- Name: strategy_points strategy_points_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_points
    ADD CONSTRAINT strategy_points_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.audit_items(id) ON DELETE CASCADE;


--
-- Name: strategy_points strategy_points_point_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_points
    ADD CONSTRAINT strategy_points_point_id_fkey FOREIGN KEY (point_id) REFERENCES public.audit_points(id) ON DELETE CASCADE;


--
-- Name: strategy_points strategy_points_strategy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_points
    ADD CONSTRAINT strategy_points_strategy_id_fkey FOREIGN KEY (strategy_id) REFERENCES public.strategies(id) ON DELETE CASCADE;


--
-- Name: strategy_points_v2 strategy_points_v2_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_points_v2
    ADD CONSTRAINT strategy_points_v2_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.audit_items(id) ON DELETE CASCADE;


--
-- Name: strategy_points_v2 strategy_points_v2_point_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_points_v2
    ADD CONSTRAINT strategy_points_v2_point_id_fkey FOREIGN KEY (point_id) REFERENCES public.audit_points(id) ON DELETE CASCADE;


--
-- Name: strategy_points_v2 strategy_points_v2_rule_set_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.strategy_points_v2
    ADD CONSTRAINT strategy_points_v2_rule_set_id_fkey FOREIGN KEY (rule_set_id) REFERENCES public.rule_sets(id) ON DELETE CASCADE;


--
-- Name: trigger_runs trigger_runs_trigger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trigger_runs
    ADD CONSTRAINT trigger_runs_trigger_id_fkey FOREIGN KEY (trigger_id) REFERENCES public.triggers(id) ON DELETE CASCADE;


--
-- Name: triggers triggers_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.triggers
    ADD CONSTRAINT triggers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: triggers triggers_strategy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.triggers
    ADD CONSTRAINT triggers_strategy_id_fkey FOREIGN KEY (strategy_id) REFERENCES public.strategies(id) ON DELETE SET NULL;


--
-- Name: workflow_instances workflow_instances_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_instances
    ADD CONSTRAINT workflow_instances_material_id_fkey FOREIGN KEY (material_id) REFERENCES public.materials(id) ON DELETE CASCADE;


--
-- Name: workflow_instances workflow_instances_material_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_instances
    ADD CONSTRAINT workflow_instances_material_version_id_fkey FOREIGN KEY (material_version_id) REFERENCES public.material_versions(id) ON DELETE CASCADE;


--
-- Name: workflow_instances workflow_instances_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_instances
    ADD CONSTRAINT workflow_instances_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.workflow_templates(id);


--
-- Name: workflow_nodes workflow_nodes_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_nodes
    ADD CONSTRAINT workflow_nodes_instance_id_fkey FOREIGN KEY (instance_id) REFERENCES public.workflow_instances(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict pGc6ecvJTYiVVp16desd2Hc3Z7HedmPvii9KBikzedw9CEgSCfj7agrv0tEYK5H

